window.CNCApp = window.CNCApp || {};

CNCApp.SvgGenerator = {
  currentSvgString: null,
  parsedShapes: [],
  detectedFillColors: [],
  detectedStrokeColors: [],
  colorMapping: new Map(), // hexColor -> dispenserId (0 means Ignore / Do not fill)
  svgBounds: { minX: 0, minY: 0, width: 100, height: 100 },
  detectedPhysicalWidthMm: null,
  detectedPhysicalHeightMm: null,

  // Примерни вградени SVG шаблони за брзо тестирање
  sampleSvgs: {
    star: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" width="100" height="100">
  <polygon points="50,5 64,36 98,36 70,57 81,91 50,70 19,91 30,57 2,36 36,36" 
           fill="#2563eb" stroke="#1d4ed8" stroke-width="1.5" />
  <circle cx="50" cy="50" r="14" fill="#dc2626" stroke="#991b1b" stroke-width="1" />
</svg>`,

    flower3Color: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" width="120" height="120">
  <circle cx="60" cy="60" r="14" fill="#d97706" />
  <path d="M 60 46 C 45 20, 75 20, 60 46 Z" fill="#2563eb" />
  <path d="M 74 60 C 100 45, 100 75, 74 60 Z" fill="#2563eb" />
  <path d="M 60 74 C 75 100, 45 100, 60 74 Z" fill="#2563eb" />
  <path d="M 46 60 C 20 75, 20 45, 46 60 Z" fill="#2563eb" />
  <circle cx="85" cy="35" r="7" fill="#059669" />
  <circle cx="85" cy="85" r="7" fill="#059669" />
  <circle cx="35" cy="85" r="7" fill="#059669" />
  <circle cx="35" cy="35" r="7" fill="#059669" />
</svg>`,

    channelsAndPockets: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 60 40" width="60mm" height="40mm">
  <!-- Тест канали широк 1.2мм и езерца со стеснување -->
  <path d="M 10 10 L 50 10 L 50 12 L 10 12 Z" fill="#2563eb" />
  <path d="M 10 18 C 10 14, 18 14, 18 18 C 18 20, 15 21, 15 24 C 15 27, 18 28, 18 32 C 18 36, 10 36, 10 32 C 10 28, 13 27, 13 24 C 13 21, 10 20, 10 18 Z" fill="#059669" />
  <path d="M 25 18 L 45 18 L 45 32 L 43 32 L 43 20 L 36 20 L 36 32 L 34 32 L 34 20 L 27 20 L 27 32 L 25 32 Z" fill="#dc2626" />
</svg>`
  },

  // Отворање на модалот за автоматско генерирање
  openModal: function(initialSvgText) {
    const modal = document.getElementById('svgGeneratorModal');
    if (!modal) return;

    if (initialSvgText) {
      this.currentSvgString = initialSvgText;
    } else if (CNCApp.State.svgData) {
      this.currentSvgString = CNCApp.State.svgData;
    } else {
      this.currentSvgString = this.sampleSvgs.channelsAndPockets;
    }

    this.parseAndAnalyze(this.currentSvgString);
    this.updateModalUI();
    modal.style.display = 'flex';
  },

  closeModal: function() {
    const modal = document.getElementById('svgGeneratorModal');
    if (modal) modal.style.display = 'none';
  },

  // Конверзија на димензија од текст во милиметри (mm, cm, in, pt, px)
  parseDimensionToMm: function(dimStr, defaultDpi = 96) {
    if (!dimStr) return null;
    const s = String(dimStr).trim().toLowerCase();
    if (s.endsWith('mm')) return parseFloat(s);
    if (s.endsWith('cm')) return parseFloat(s) * 10;
    if (s.endsWith('in')) return parseFloat(s) * 25.4;
    if (s.endsWith('pt')) return parseFloat(s) * (25.4 / 72);
    if (s.endsWith('px')) return parseFloat(s) * (25.4 / defaultDpi);
    const n = parseFloat(s);
    return isNaN(n) ? null : n * (25.4 / defaultDpi);
  },

  // Парсирање на SVG во прегледни векторски форми со препознавање на CSS стилови и класи
  parseAndAnalyze: function(svgText) {
    this.currentSvgString = svgText;
    this.parsedShapes = [];
    this.detectedFillColors = [];
    this.detectedStrokeColors = [];
    this.colorMapping.clear();
    this.detectedPhysicalWidthMm = null;
    this.detectedPhysicalHeightMm = null;

    if (!svgText || !svgText.trim()) return;

    const parser = new DOMParser();
    const doc = parser.parseFromString(svgText, 'image/svg+xml');
    const svgEl = doc.querySelector('svg');
    if (!svgEl) return;

    // 1. Екстракција на CSS класи од <style> ознаки (на пр. во CorelDRAW .fil1 {fill:#D2D4D5})
    const cssRules = {};
    const styleTags = doc.querySelectorAll('style');
    styleTags.forEach(st => {
      const txt = st.textContent || '';
      const regex = /\.([a-zA-Z0-9_-]+)\s*\{([^}]+)\}/g;
      let match;
      while ((match = regex.exec(txt)) !== null) {
        const clsName = match[1];
        const decls = match[2];
        cssRules[clsName] = cssRules[clsName] || {};
        decls.split(';').forEach(d => {
          const parts = d.split(':');
          if (parts.length === 2) {
            const k = parts[0].trim().toLowerCase();
            const v = parts[1].trim();
            cssRules[clsName][k] = v;
          }
        });
      }
    });

    // 2. Пресметка на физички димензии и viewBox
    const rawW = svgEl.getAttribute('width');
    const rawH = svgEl.getAttribute('height');
    const parsedW_mm = this.parseDimensionToMm(rawW);
    const parsedH_mm = this.parseDimensionToMm(rawH);

    let vb = svgEl.getAttribute('viewBox');
    let minX = 0, minY = 0, vbWidth = 100, vbHeight = 100;
    if (vb) {
      const parts = vb.trim().split(/[\s,]+/).map(parseFloat);
      if (parts.length === 4) {
        minX = parts[0];
        minY = parts[1];
        vbWidth = parts[2];
        vbHeight = parts[3];
      }
    } else if (parsedW_mm && parsedH_mm) {
      vbWidth = parsedW_mm;
      vbHeight = parsedH_mm;
    }

    this.svgBounds = { minX, minY, width: vbWidth, height: vbHeight };

    if (parsedW_mm && parsedW_mm > 0) {
      this.detectedPhysicalWidthMm = parseFloat(parsedW_mm.toFixed(3));
      this.detectedPhysicalHeightMm = parsedH_mm ? parseFloat(parsedH_mm.toFixed(3)) : parseFloat(((parsedW_mm * vbHeight) / vbWidth).toFixed(3));
    } else {
      this.detectedPhysicalWidthMm = Math.round(vbWidth);
      this.detectedPhysicalHeightMm = Math.round(vbHeight);
    }

    // 3. Пребарување на сите геометриски облици
    const selectors = ['path', 'line', 'polyline', 'polygon', 'rect', 'circle', 'ellipse'];
    const nodes = svgEl.querySelectorAll(selectors.join(','));

    const fillSet = new Set();
    const strokeSet = new Set();

    nodes.forEach((node, nodeIdx) => {
      // Идентификувај стил според атрибути, CSS класа или inline style
      let fillVal = node.getAttribute('fill');
      let strokeVal = node.getAttribute('stroke');

      const classAttr = node.getAttribute('class') || '';
      const classes = classAttr.split(/\s+/).filter(Boolean);
      for (let cls of classes) {
        if (cssRules[cls]) {
          if (!fillVal && cssRules[cls].fill) fillVal = cssRules[cls].fill;
          if (!strokeVal && cssRules[cls].stroke) strokeVal = cssRules[cls].stroke;
        }
      }

      if (node.style) {
        if (!fillVal && node.style.fill) fillVal = node.style.fill;
        if (!strokeVal && node.style.stroke) strokeVal = node.style.stroke;
      }

      // Нормализација
      const isFillNone = !fillVal || fillVal === 'none' || fillVal === 'transparent';
      const isStrokeNone = !strokeVal || strokeVal === 'none' || strokeVal === 'transparent';

      const normFill = isFillNone ? null : this.normalizeColorToHex(fillVal);
      const normStroke = isStrokeNone ? null : this.normalizeColorToHex(strokeVal);

      if (normFill) fillSet.add(normFill);
      if (normStroke) strokeSet.add(normStroke);

      const dStrings = this.convertNodeToPathStrings(node);
      dStrings.forEach(d => {
        if (d && d.trim().length > 1) {
          this.parsedShapes.push({
            d: d.trim(),
            fillColor: normFill,
            strokeColor: normStroke,
            nodeType: node.tagName.toLowerCase(),
            elementIndex: nodeIdx
          });
        }
      });
    });

    this.detectedFillColors = Array.from(fillSet);
    this.detectedStrokeColors = Array.from(strokeSet);

    // Автоматско мапирање на секоја откриена боја на полнење со најсоодветен диспензер
    this.detectedFillColors.forEach(hex => {
      // Ако е чиста бела боја (#ffffff) и е единечен правоаголник/позадина, стави на Ignore (0)
      if (hex === '#ffffff') {
        this.colorMapping.set(hex, 0); // 0 = Ignore
      } else {
        const matchedDisp = this.findClosestDispenser(hex);
        this.colorMapping.set(hex, matchedDisp.id);
      }
    });

    // Доколку нема бои за полнење, мапирај ги боите на линии
    if (this.detectedFillColors.length === 0) {
      this.detectedStrokeColors.forEach(hex => {
        const matchedDisp = this.findClosestDispenser(hex);
        this.colorMapping.set(hex, matchedDisp.id);
      });
    }
  },

  // Нормализација на боја во чист #rrggbb формат
  normalizeColorToHex: function(colorStr) {
    if (!colorStr) return null;
    const c = colorStr.trim().toLowerCase();
    if (c === 'none' || c === 'transparent') return null;

    if (c.startsWith('#')) {
      if (c.length === 4) {
        return '#' + c[1] + c[1] + c[2] + c[2] + c[3] + c[3];
      }
      return c.substring(0, 7);
    }

    try {
      const ctx = document.createElement('canvas').getContext('2d');
      ctx.fillStyle = c;
      return ctx.fillStyle;
    } catch (e) {
      return null;
    }
  },

  // Наоѓање најблизок диспензер според боја
  findClosestDispenser: function(hexColor) {
    const dispensers = CNCApp.State.machine.dispensers || [];
    if (dispensers.length === 0) return { id: 1, name: 'Боја 1' };

    const rgb1 = this.hexToRgb(hexColor);
    let bestDist = Infinity;
    let bestDisp = dispensers[0];

    dispensers.forEach(d => {
      const rgb2 = this.hexToRgb(d.color);
      const dist = Math.hypot(rgb1.r - rgb2.r, rgb1.g - rgb2.g, rgb1.b - rgb2.b);
      if (dist < bestDist) {
        bestDist = dist;
        bestDisp = d;
      }
    });

    return bestDisp;
  },

  hexToRgb: function(hex) {
    let clean = (hex || '#000000').replace('#', '');
    if (clean.length === 3) {
      clean = clean[0] + clean[0] + clean[1] + clean[1] + clean[2] + clean[2];
    }
    const num = parseInt(clean, 16);
    return {
      r: (num >> 16) & 255,
      g: (num >> 8) & 255,
      b: num & 255
    };
  },

  // Претворање на кој било SVG облик во 'd' за path
  convertNodeToPathStrings: function(node) {
    const tag = node.tagName.toLowerCase();

    if (tag === 'path') {
      const d = (node.getAttribute('d') || '').trim();
      return d ? [d] : [];
    }

    if (tag === 'line') {
      const x1 = node.getAttribute('x1') || 0;
      const y1 = node.getAttribute('y1') || 0;
      const x2 = node.getAttribute('x2') || 0;
      const y2 = node.getAttribute('y2') || 0;
      return [`M ${x1} ${y1} L ${x2} ${y2}`];
    }

    if (tag === 'polyline' || tag === 'polygon') {
      const rawPoints = (node.getAttribute('points') || '').trim();
      const coords = rawPoints.split(/[\s,]+/).map(parseFloat).filter(n => !isNaN(n));
      if (coords.length < 4) return [];

      let d = `M ${coords[0]} ${coords[1]}`;
      for (let i = 2; i < coords.length; i += 2) {
        d += ` L ${coords[i]} ${coords[i + 1]}`;
      }
      if (tag === 'polygon') d += ' Z';
      return [d];
    }

    if (tag === 'rect') {
      const x = parseFloat(node.getAttribute('x') || 0);
      const y = parseFloat(node.getAttribute('y') || 0);
      const w = parseFloat(node.getAttribute('width') || 0);
      const h = parseFloat(node.getAttribute('height') || 0);
      return [`M ${x} ${y} L ${x + w} ${y} L ${x + w} ${y + h} L ${x} ${y + h} Z`];
    }

    if (tag === 'circle') {
      const cx = parseFloat(node.getAttribute('cx') || 0);
      const cy = parseFloat(node.getAttribute('cy') || 0);
      const r = parseFloat(node.getAttribute('r') || 0);
      if (r <= 0) return [];
      return [`M ${cx - r} ${cy} A ${r} ${r} 0 1 0 ${cx + r} ${cy} A ${r} ${r} 0 1 0 ${cx - r} ${cy}`];
    }

    if (tag === 'ellipse') {
      const cx = parseFloat(node.getAttribute('cx') || 0);
      const cy = parseFloat(node.getAttribute('cy') || 0);
      const rx = parseFloat(node.getAttribute('rx') || 0);
      const ry = parseFloat(node.getAttribute('ry') || 0);
      if (rx <= 0 || ry <= 0) return [];
      return [`M ${cx - rx} ${cy} A ${rx} ${ry} 0 1 0 ${cx + rx} ${cy} A ${rx} ${ry} 0 1 0 ${cx - rx} ${cy}`];
    }

    return [];
  },

  // Ажурирање на корисничкиот интерфејс во модалот
  updateModalUI: function() {
    const previewBox = document.getElementById('svgGenPreviewSvg');
    const colorMappingList = document.getElementById('svgGenColorList');
    const statsLabel = document.getElementById('svgGenStats');
    const targetWidthInp = document.getElementById('svgGenTargetWidth');

    if (previewBox) {
      previewBox.innerHTML = this.currentSvgString || '<div style="color:#94a3b8;padding:20px;">Нема вчитано SVG</div>';
    }

    // Автоматско пополнување на физичката ширина од SVG (на пример 59.96mm)
    if (targetWidthInp) {
      if (this.detectedPhysicalWidthMm && this.detectedPhysicalWidthMm > 0) {
        targetWidthInp.value = this.detectedPhysicalWidthMm;
      } else {
        const detectedW = this.svgBounds ? Math.round(this.svgBounds.width) : 50;
        targetWidthInp.value = Math.min(Math.max(detectedW, 20), 150);
      }
    }

    const fillsCount = this.detectedFillColors.length;
    const strokesCount = this.detectedStrokeColors.length;

    if (statsLabel) {
      let dimText = this.detectedPhysicalWidthMm ? `${this.detectedPhysicalWidthMm} × ${this.detectedPhysicalHeightMm} mm` : `${Math.round(this.svgBounds.width)} × ${Math.round(this.svgBounds.height)} pt`;
      statsLabel.innerText = `Димензии: ${dimText} | Полиња за полнење: ${fillsCount} | Линии: ${strokesCount}`;
    }

    // Список на бои со селектор за диспензер
    if (colorMappingList) {
      colorMappingList.innerHTML = '';
      const colorsToShow = fillsCount > 0 ? this.detectedFillColors : this.detectedStrokeColors;

      if (colorsToShow.length === 0) {
        colorMappingList.innerHTML = '<span style="color:#64748b;font-size:11px;">Не се детектирани бои. Ќе се користи Боја 1.</span>';
      } else {
        const dispensers = CNCApp.State.machine.dispensers || [];
        colorsToShow.forEach(hex => {
          const row = document.createElement('div');
          row.style.display = 'flex';
          row.style.alignItems = 'center';
          row.style.gap = '8px';
          row.style.marginBottom = '5px';
          row.style.padding = '4px 6px';
          row.style.background = '#ffffff';
          row.style.borderRadius = '4px';
          row.style.border = '1px solid #e2e8f0';

          const currentDispId = this.colorMapping.get(hex) ?? 1;

          let dispOptions = `<option value="0" ${currentDispId === 0 ? 'selected' : ''}>🚫 Игнорирај (Не пополнувај)</option>`;
          dispOptions += dispensers.map(d => 
            `<option value="${d.id}" ${d.id === currentDispId ? 'selected' : ''}>${d.name} (${d.color})</option>`
          ).join('');

          row.innerHTML = `
            <span style="display:inline-block;width:18px;height:18px;border-radius:4px;background:${hex};border:1px solid #94a3b8;box-shadow:0 1px 2px rgba(0,0,0,0.15);"></span>
            <span style="font-family:monospace;font-size:11px;min-width:65px;font-weight:600;color:#1e293b;">${hex}</span>
            <span style="font-size:11px;color:#64748b;">➔ Диспензер:</span>
            <select class="inp inp-sm" style="flex:1;">
              ${dispOptions}
            </select>
          `;

          const sel = row.querySelector('select');
          sel.onchange = (e) => {
            this.colorMapping.set(hex, parseInt(e.target.value));
          };

          colorMappingList.appendChild(row);
        });
      }
    }
  },

  // =========================================================================
  // ЕВКЛИДОВА ТРАНСФОРМАЦИЈА НА РАСТОЈАНИЕ (2D EUCLIDEAN DISTANCE TRANSFORM)
  // Прецизен Meijster алгоритам со O(W*H) линеарна сложеност за наоѓање на клиренс
  // =========================================================================
  computeEDT: function(binaryGrid, w, h) {
    const inf = 1e9;
    const d1 = new Float32Array(w * h);

    // Фаза 1: 1D по колони (од горе надолу и од долу нагоре)
    for (let x = 0; x < w; x++) {
      let dist = inf;
      for (let y = 0; y < h; y++) {
        dist = binaryGrid[y * w + x] === 0 ? 0 : dist + 1;
        d1[y * w + x] = dist;
      }
      dist = inf;
      for (let y = h - 1; y >= 0; y--) {
        dist = binaryGrid[y * w + x] === 0 ? 0 : dist + 1;
        if (dist < d1[y * w + x]) d1[y * w + x] = dist;
      }
    }

    // Фаза 2: Хоризонтална параболична обвивка
    const dt = new Float32Array(w * h);
    const s = new Float32Array(w);
    const t = new Int32Array(w);

    for (let y = 0; y < h; y++) {
      const rowOffset = y * w;
      let q = 0;
      s[0] = -inf;
      t[0] = 0;

      for (let u = 1; u < w; u++) {
        const f_u = d1[rowOffset + u] * d1[rowOffset + u];
        while (q >= 0) {
          const t_q = t[q];
          const f_t = d1[rowOffset + t_q] * d1[rowOffset + t_q];
          const sep = (f_u - f_t + u * u - t_q * t_q) / (2.0 * (u - t_q));
          if (sep <= s[q]) {
            q--;
          } else {
            q++;
            t[q] = u;
            s[q] = sep;
            break;
          }
        }
        if (q < 0) {
          q = 0;
          t[0] = u;
          s[0] = -inf;
        }
      }

      for (let u = w - 1; u >= 0; u--) {
        while (q > 0 && s[q] > u) q--;
        const t_q = t[q];
        const d1Val = d1[rowOffset + t_q];
        dt[rowOffset + u] = Math.sqrt(d1Val * d1Val + (u - t_q) * (u - t_q));
      }
    }

    return dt;
  },

  // =========================================================================
  // АВТОМАТСКИ ТЕЖИШТА И КАНАЛИ (POLE OF INACCESSIBILITY / MEDIAL AXIS SAMPLER)
  // Наоѓа локални максимуми на езерца и сртови на канали, подалеку од ѕидовите
  // =========================================================================
  samplePocketMedialAxis: function(pathsForColor, options) {
    const {
      targetWidthMm = 60,
      targetHeightMm = 40,
      stepMm = 2.0,
      minClearanceMm = 0.25,
      invertY = true,
      offsetX = 0,
      offsetY = 0,
      canvasResolution = 20 // 20 пиксели по mm = резолуција од 0.05 mm
    } = options;

    const bounds = this.svgBounds;
    const canvasW = Math.max(10, Math.ceil(targetWidthMm * canvasResolution));
    const canvasH = Math.max(10, Math.ceil(targetHeightMm * canvasResolution));

    // Создади офскрин канвас за брза расеризација на векторските форми од таа боја
    const offCanvas = document.createElement('canvas');
    offCanvas.width = canvasW;
    offCanvas.height = canvasH;
    const ctx = offCanvas.getContext('2d');
    if (!ctx) return [];

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvasW, canvasH);

    // Скалирање од SVG viewBox кон физичките пиксели на офскрин канвасот
    ctx.save();
    const scaleX = canvasW / bounds.width;
    const scaleY = canvasH / bounds.height;
    ctx.scale(scaleX, scaleY);
    ctx.translate(-bounds.minX, -bounds.minY);

    ctx.fillStyle = '#000000';
    for (let pObj of pathsForColor) {
      try {
        const p2d = new Path2D(pObj.d);
        ctx.fill(p2d, 'evenodd');
      } catch (e) {
        // Доколку некој прелистувач не поддржува одреден path2d
      }
    }
    ctx.restore();

    // Екстракција на бинарна маска (1 = внатре во полето за полнење, 0 = надвор)
    const imgData = ctx.getImageData(0, 0, canvasW, canvasH);
    const pixels = imgData.data;
    const binaryGrid = new Uint8Array(canvasW * canvasH);

    for (let i = 0; i < pixels.length; i += 4) {
      // Црните пиксели се внатрешност на полето
      if (pixels[i] < 128 && pixels[i + 3] > 128) {
        binaryGrid[i / 4] = 1;
      }
    }

    // Пресметај го точното растојание до најблискиот раб за секој пиксел
    const edt = this.computeEDT(binaryGrid, canvasW, canvasH);

    // Соберете ги сите пиксели со доволно безбеден клиренс
    const minClearancePx = minClearanceMm * canvasResolution;
    const candidates = [];

    for (let y = 1; y < canvasH - 1; y++) {
      const row = y * canvasW;
      for (let x = 1; x < canvasW - 1; x++) {
        const d = edt[row + x];
        if (d >= minClearancePx) {
          candidates.push({ x, y, d });
        }
      }
    }

    if (candidates.length === 0) return [];

    // Сортирај ги кандидатите од најдлабоко тежиште (најголем клиренс) кон поплитко
    candidates.sort((a, b) => b.d - a.d);

    // Просторно селектирање (Greedy Inscribed Disk / Poisson-Disk)
    const stepPx = Math.max(1, stepMm * canvasResolution);
    const gridCell = stepPx;
    const gridW = Math.ceil(canvasW / gridCell);
    const gridH = Math.ceil(canvasH / gridCell);
    const spatialGrid = new Map();

    const selectedPoints = [];

    for (let i = 0; i < candidates.length; i++) {
      const c = candidates[i];
      const gx = Math.floor(c.x / gridCell);
      const gy = Math.floor(c.y / gridCell);

      let tooClose = false;
      for (let dx = -1; dx <= 1 && !tooClose; dx++) {
        for (let dy = -1; dy <= 1 && !tooClose; dy++) {
          const key = (gy + dy) * gridW + (gx + dx);
          const list = spatialGrid.get(key);
          if (list) {
            for (let j = 0; j < list.length; j++) {
              const p = list[j];
              const distSq = (c.x - p.x) * (c.x - p.x) + (c.y - p.y) * (c.y - p.y);
              if (distSq < stepPx * stepPx) {
                tooClose = true;
                break;
              }
            }
          }
        }
      }

      if (!tooClose) {
        selectedPoints.push(c);
        const key = gy * gridW + gx;
        if (!spatialGrid.has(key)) spatialGrid.set(key, []);
        spatialGrid.get(key).push(c);
      }
    }

    if (selectedPoints.length === 0) return [];

    // Претвори пиксели во реални CNC милиметри
    const mmPoints = selectedPoints.map(sp => {
      const normX = sp.x / canvasResolution;
      let normY = sp.y / canvasResolution;
      if (invertY) {
        normY = targetHeightMm - normY;
      }
      return {
        x: parseFloat((normX + offsetX).toFixed(3)),
        y: parseFloat((normY + offsetY).toFixed(3)),
        clearance: parseFloat((sp.d / canvasResolution).toFixed(3))
      };
    });

    // Оптимизација на патеката на движење (Nearest Neighbor TSP) за мазно одење на главата
    const ordered = [];
    const unvisited = [...mmPoints];

    // Почни од точката најблиску до горниот лев агол
    unvisited.sort((a, b) => (b.y - a.y) || (a.x - b.x));
    let current = unvisited.shift();
    ordered.push(current);

    while (unvisited.length > 0) {
      let bestDist = Infinity;
      let bestIdx = 0;
      for (let i = 0; i < unvisited.length; i++) {
        const d = Math.hypot(current.x - unvisited[i].x, current.y - unvisited[i].y);
        if (d < bestDist) {
          bestDist = d;
          bestIdx = i;
        }
      }
      current = unvisited.splice(bestIdx, 1)[0];
      ordered.push(current);
    }

    return ordered;
  },

  // =========================================================================
  // ГЛАВНА ФУНКЦИЈА: ГЕНЕРИРАЊЕ НА ТОЧКИ СО ИЗБРАНИОТ РЕЖИМ
  // =========================================================================
  generatePoints: function(options) {
    const {
      mode = 'pockets',         // 'pockets' (тежишта и канали), 'lines' (контури), 'dots' (капки по раб)
      stepMm = 2.0,             // Чекор за точки (мм)
      targetWidthMm = 60,       // Физичка ширина во мм
      invertY = true,           // Инверзија на Y оска за CNC
      offsetX = 0,              // Офсет X (мм)
      offsetY = 0,              // Офсет Y (мм)
      speed = 1000,             // Работна брзина на дозирање F mm/min
      travelNearSpeed = 2000,   // Брзина меѓу блиски езерца F mm/min
      travelFarSpeed = 5000,    // Брзина долг премин / измена на алат F mm/min
      minClearanceMm = 0.18,    // Безбедно растојание од ѕид (мм)
      dropTimeMs = 200,         // Време за капка (ms)
      groupByDispenser = true   // Групирање по боја
    } = options;

    if (!this.parsedShapes || this.parsedShapes.length === 0) {
      alert("⚠️ Нема детектирани векторски патеки во овој SVG фајл.");
      return [];
    }

    const bounds = this.svgBounds || { minX: 0, minY: 0, width: 100, height: 100 };
    const targetHeightMm = parseFloat(((targetWidthMm * bounds.height) / bounds.width).toFixed(3));

    // =========================================================================
    // РЕЖИМ 1: ТЕЖИШТА НА ПОЛИЊА И КАНАЛИ (MEDIAL AXIS POCKET SAMPLER) - ПРЕПОРАЧАН
    // =========================================================================
    if (mode === 'pockets') {
      const finalPoints = [];

      // Групирај ги формите според нивната боја на полнење (САМО облици со вистинска боја)
      const shapesByFill = new Map();
      this.parsedShapes.forEach(shape => {
        if (!shape.fillColor) return; // ИГНОРИРАЈ СЕ ШТО НЕМА ВИСТИНСКА БОЈА НА ПОЛНЕЊЕ!
        const fill = shape.fillColor;
        if (!shapesByFill.has(fill)) shapesByFill.set(fill, []);
        shapesByFill.get(fill).push(shape);
      });

      // Сортирај по доделен диспензер за минимални промени на алат
      const sortedFills = Array.from(shapesByFill.keys()).sort((a, b) => {
        const dispA = this.colorMapping.get(a) ?? 1;
        const dispB = this.colorMapping.get(b) ?? 1;
        return dispA - dispB;
      });

      sortedFills.forEach((fillHex, groupIdx) => {
        const dispId = this.colorMapping.get(fillHex) ?? 1;
        if (dispId <= 0) return; // Игнорирана боја

        const shapes = shapesByFill.get(fillHex);
        const sampledPoints = this.samplePocketMedialAxis(shapes, {
          targetWidthMm,
          targetHeightMm,
          stepMm,
          minClearanceMm,
          invertY,
          offsetX,
          offsetY,
          canvasResolution: 20
        });

        sampledPoints.forEach((sp, pIdx) => {
          const ptObj = CNCApp.State.createPoint(sp.x, sp.y);
          ptObj.dispenser = dispId;
          ptObj.speed = speed;
          ptObj.lower = true;
          ptObj.valveStart = true;
          ptObj.time = dropTimeMs;
          ptObj.valveStop = true;
          ptObj.raise = true;
          ptObj.clearance = sp.clearance;
          ptObj.group1 = `Поле_${groupIdx + 1}`;
          ptObj.group2 = `Дисп${dispId}`;

          finalPoints.push(ptObj);
        });
      });

      if (finalPoints.length === 0) {
        alert("⚠️ Не беа пронајдени затворени полиња со доволна ширина за дозирање со овие параметри.");
        return [];
      }

      // Пресметка на динамички брзини (F) за секоја точка според правилата:
      // 1. Прва точка и измена на диспензер / алат: брз премин (travelFarSpeed, 5000)
      // 2. Движење меѓу различни езерца со подигнат диспензер:
      //    - ако растојанието е големо (>10mm): travelFarSpeed (5000)
      //    - ако е блиско (<=10mm): travelNearSpeed (2000)
      // 3. Капки во исто езерце (растојание <= 3.5mm): работна брзина на дозирање (speed, 1000)
      finalPoints.forEach((p, idx) => {
        if (idx === 0) {
          p.speed = travelFarSpeed;
          return;
        }
        const prev = finalPoints[idx - 1];
        const dist = Math.hypot(p.x - prev.x, p.y - prev.y);

        if (p.dispenser !== prev.dispenser) {
          p.speed = travelFarSpeed;
        } else if (p.group1 !== prev.group1 || (prev.raise && p.lower && dist > 3.5)) {
          p.speed = (dist > 10.0) ? travelFarSpeed : travelNearSpeed;
        } else {
          if (dist <= 3.5) {
            p.speed = speed;
          } else if (dist <= 10.0) {
            p.speed = travelNearSpeed;
          } else {
            p.speed = travelFarSpeed;
          }
        }
      });

      return finalPoints;
    }

    // =========================================================================
    // РЕЖИМ 2 И 3: КОНТУРНИ ЛИНИИ ИЛИ КАПКИ ПО РАБОВИ
    // =========================================================================
    let tempSvg = document.getElementById('__temp_svg_sampler__');
    if (!tempSvg) {
      tempSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
      tempSvg.id = '__temp_svg_sampler__';
      tempSvg.style.position = 'absolute';
      tempSvg.style.width = '0';
      tempSvg.style.height = '0';
      tempSvg.style.visibility = 'hidden';
      document.body.appendChild(tempSvg);
    }
    tempSvg.innerHTML = '';

    let scaleRatio = targetWidthMm / bounds.width;
    const rawSegments = [];

    this.parsedShapes.forEach((item, elemIdx) => {
      const activeColor = item.fillColor || item.strokeColor || '#2563eb';
      const dispId = this.colorMapping.get(activeColor) ?? 1;
      if (dispId <= 0) return;

      const pathEl = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      pathEl.setAttribute('d', item.d);
      tempSvg.appendChild(pathEl);

      try {
        const totalLen = pathEl.getTotalLength();
        if (totalLen <= 0.001) return;

        const stepInSvg = Math.max(0.2, stepMm / scaleRatio);
        const numSteps = Math.max(1, Math.round(totalLen / stepInSvg));
        const actualStep = totalLen / numSteps;

        const pts = [];
        for (let i = 0; i <= numSteps; i++) {
          const dist = i === numSteps ? totalLen : i * actualStep;
          const pt = pathEl.getPointAtLength(dist);
          pts.push({ x: pt.x, y: pt.y });
        }

        if (pts.length > 0) {
          rawSegments.push({
            dispenser: dispId,
            points: pts,
            originalColor: activeColor,
            segmentId: elemIdx + 1
          });
        }
      } catch (err) {
        // грешка при семплирање на контура
      } finally {
        tempSvg.removeChild(pathEl);
      }
    });

    if (rawSegments.length === 0) {
      alert("⚠️ Не можеше да се извлечат точки од контурите на овој SVG.");
      return [];
    }

    let orderedSegments = rawSegments;
    if (groupByDispenser) {
      orderedSegments = [...rawSegments].sort((a, b) => a.dispenser - b.dispenser);
    }

    const finalPoints = [];

    orderedSegments.forEach((seg) => {
      const pts = seg.points;
      const totalInSeg = pts.length;

      pts.forEach((p, pIdx) => {
        const normX = (p.x - bounds.minX) * scaleRatio;
        let normY = (p.y - bounds.minY) * scaleRatio;
        if (invertY) normY = targetHeightMm - normY;

        const worldX = parseFloat((normX + offsetX).toFixed(3));
        const worldY = parseFloat((normY + offsetY).toFixed(3));

        const ptObj = CNCApp.State.createPoint(worldX, worldY);
        ptObj.dispenser = seg.dispenser;
        ptObj.speed = speed;
        ptObj.group1 = `Контура_${seg.segmentId}`;
        ptObj.group2 = `Дисп${seg.dispenser}`;

        if (mode === 'lines') {
          if (pIdx === 0) {
            ptObj.lower = true;
            ptObj.valveStart = true;
            ptObj.valveStop = false;
            ptObj.raise = false;
            ptObj.time = '';
          } else if (pIdx === totalInSeg - 1) {
            ptObj.lower = false;
            ptObj.valveStart = false;
            ptObj.valveStop = true;
            ptObj.raise = true;
            ptObj.time = '';
          } else {
            ptObj.lower = false;
            ptObj.valveStart = false;
            ptObj.valveStop = false;
            ptObj.raise = false;
            ptObj.time = '';
          }
        } else {
          ptObj.lower = true;
          ptObj.valveStart = true;
          ptObj.time = dropTimeMs;
          ptObj.valveStop = true;
          ptObj.raise = true;
        }

        finalPoints.push(ptObj);
      });
    });

    return finalPoints;
  },

  // Примена на новогенерираната патека врз проектот
  applyToProject: function(replaceExisting = true) {
    const mode = document.querySelector('input[name="svgGenMode"]:checked')?.value || 'pockets';
    const stepMm = parseFloat(document.getElementById('svgGenStep')?.value) || 2.0;
    const targetWidthMm = parseFloat(document.getElementById('svgGenTargetWidth')?.value) || (this.detectedPhysicalWidthMm || 60);
    const invertY = document.getElementById('svgGenInvertY')?.checked ?? true;
    const offsetX = parseFloat(document.getElementById('svgGenOffsetX')?.value) || 0;
    const offsetY = parseFloat(document.getElementById('svgGenOffsetY')?.value) || 0;
    const speed = Math.round(parseFloat(document.getElementById('svgGenSpeed')?.value) || 1000);
    const travelNearSpeed = Math.round(parseFloat(document.getElementById('svgGenTravelNearSpeed')?.value) || 2000);
    const travelFarSpeed = Math.round(parseFloat(document.getElementById('svgGenTravelFarSpeed')?.value) || 5000);
    const minClearanceMm = parseFloat(document.getElementById('svgGenMinClearance')?.value) || 0.18;
    const dropTime = Math.round(parseFloat(document.getElementById('svgGenDropTime')?.value) || 200);
    const groupByColor = document.getElementById('svgGenGroupByColor')?.checked ?? true;

    const newPoints = this.generatePoints({
      mode,
      stepMm,
      targetWidthMm,
      invertY,
      offsetX,
      offsetY,
      speed,
      travelNearSpeed,
      travelFarSpeed,
      minClearanceMm,
      dropTimeMs: dropTime,
      groupByDispenser: groupByColor
    });

    if (newPoints.length === 0) return;

    if (replaceExisting) {
      CNCApp.State.points = newPoints;
    } else {
      CNCApp.State.points = CNCApp.State.points.concat(newPoints);
    }

    // Постави го и SVG-то во позадина на платното за совршено поклопување
    if (this.currentSvgString && CNCApp.Parser) {
      CNCApp.Parser.loadSvgContent(this.currentSvgString);
    }

    CNCApp.Table.enforceDispenserSafety();
    CNCApp.State.selectedIndices.clear();
    CNCApp.State.activePointIndex = 0;
    CNCApp.State.selectedIndices.add(0);
    CNCApp.State.snapshot();
    CNCApp.Table.render();
    CNCApp.Canvas.resetView();
    CNCApp.GCode.updateCycleTime();

    this.closeModal();

    let modeTitle = '🎯 Тежишта на полиња и оски на канали (Полнење)';
    if (mode === 'lines') modeTitle = '📏 Контури (Линии)';
    if (mode === 'dots') modeTitle = '⚪ Капки по контури';

    alert(`🎉 Успешно се генерирани ${newPoints.length} точки од SVG фајлот!\n\n` +
          `• Режим: ${modeTitle}\n` +
          `• Чекор: ${stepMm} mm\n` +
          `• Ширина на модел: ${targetWidthMm} mm\n` +
          `• Време за циклус: ${document.getElementById('cycleTimeDisplay').innerText}`);
  }
};
