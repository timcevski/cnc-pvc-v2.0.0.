window.CNCApp = window.CNCApp || {};

CNCApp.Canvas = {
  canvas: null,
  ctx: null,
  scale: 15,
  panX: 50,
  panY: 50,
  isDragging: false,
  isPanning: false,
  isBoxSelecting: false,
  draggedIndex: null,
  dragStartMouse: { x: 0, y: 0 },
  dragStartPoints: new Map(),
  startX: 0,
  startY: 0,
  boxStartX: 0,
  boxStartY: 0,
  boxCurX: 0,
  boxCurY: 0,

  init: function() {
    this.canvas = document.getElementById('mainCanvas');
    this.ctx = this.canvas.getContext('2d');
    this.resize();

    window.addEventListener('resize', () => { this.resize(); this.render(); });
    this.panY = this.canvas.height - 50;

    this.bindEvents();
    this.render();
  },

  resize: function() {
    const wrap = document.getElementById('canvasWrapper');
    this.canvas.width = wrap.clientWidth;
    this.canvas.height = wrap.clientHeight;
  },

  resetView: function() {
    this.resize();
    const w = this.canvas.width;
    const h = this.canvas.height;
    if (w <= 0 || h <= 0) return;

    let minX = 0;
    let minY = 0;
    let maxX = 40;
    let maxY = 40;

    const pts = CNCApp.State.points;
    if (pts && pts.length > 0) {
      pts.forEach(p => {
        if (p.x > maxX) maxX = p.x;
        if (p.y > maxY) maxY = p.y;
        if (p.x < minX) minX = p.x;
        if (p.y < minY) minY = p.y;
      });
    }

    if (CNCApp.State.svgImage) {
      const sw = (CNCApp.State.svgImage.width || 100) / 3.7795;
      const sh = (CNCApp.State.svgImage.height || 100) / 3.7795;
      if (sw > maxX) maxX = sw;
      if (sh > maxY) maxY = sh;
    }

    const spanX = (maxX - minX) || 40;
    const spanY = (maxY - minY) || 40;
    const paddingPx = 50;

    const availW = Math.max(50, w - paddingPx * 2);
    const availH = Math.max(50, h - paddingPx * 2);

    const scaleX = availW / spanX;
    const scaleY = availH / spanY;
    this.scale = Math.min(scaleX, scaleY);
    if (this.scale <= 0.05) this.scale = 0.05;
    if (this.scale > 80) this.scale = 80;

    const drawnW = spanX * this.scale;
    const drawnH = spanY * this.scale;

    this.panX = paddingPx + (availW - drawnW) / 2 - (minX * this.scale);
    this.panY = h - (paddingPx + (availH - drawnH) / 2) + (minY * this.scale);

    this.render();
  },

  worldToScreen: function(wx, wy) {
    return {
      x: this.panX + wx * this.scale,
      y: this.panY - wy * this.scale
    };
  },

  screenToWorld: function(sx, sy) {
    return {
      x: (sx - this.panX) / this.scale,
      y: (this.panY - sy) / this.scale
    };
  },

  bindEvents: function() {
    const c = this.canvas;
    const coordLbl = document.getElementById('coordDisplay');

    c.addEventListener('wheel', (e) => {
      e.preventDefault();
      const zoomFactor = e.deltaY < 0 ? 1.15 : 0.85;
      const mouse = this.screenToWorld(e.offsetX, e.offsetY);
      this.scale *= zoomFactor;
      this.panX = e.offsetX - mouse.x * this.scale;
      this.panY = e.offsetY + mouse.y * this.scale;
      this.render();
    });

    c.addEventListener('mousedown', (e) => {
      if (e.button === 1 || e.spaceKey) {
        this.isPanning = true;
        this.startX = e.clientX - this.panX;
        this.startY = e.clientY - this.panY;
        return;
      }

      if (e.button === 0) {
        const mouse = this.screenToWorld(e.offsetX, e.offsetY);
        const idx = this.findHitPoint(mouse.x, mouse.y);

        if (CNCApp.State.isAddMode) {
          CNCApp.Table.insertNewPointAt(mouse.x, mouse.y);
          return;
        }

        if (idx !== null) {
          this.isDragging = true;
          this.draggedIndex = idx;
          CNCApp.State.activePointIndex = idx;
          if (!e.ctrlKey && !e.shiftKey && !CNCApp.State.selectedIndices.has(idx)) {
            CNCApp.State.selectedIndices.clear();
          }
          CNCApp.State.selectedIndices.add(idx);

          this.dragStartMouse = { x: mouse.x, y: mouse.y };
          this.dragStartPoints.clear();
          CNCApp.State.selectedIndices.forEach(sIdx => {
            const p = CNCApp.State.points[sIdx];
            this.dragStartPoints.set(sIdx, { x: p.x, y: p.y });
          });

          CNCApp.Table.render();
          CNCApp.Table.scrollToRow(idx);
          this.render();
        } else {
          this.isBoxSelecting = true;
          this.isAdditiveSelection = e.shiftKey || e.ctrlKey;
          this.boxStartX = e.offsetX;
          this.boxStartY = e.offsetY;
          this.boxCurX = e.offsetX;
          this.boxCurY = e.offsetY;
          if (!e.ctrlKey && !e.shiftKey) {
            CNCApp.State.selectedIndices.clear();
          }
          this.render();
        }
      }
    });

    window.addEventListener('mousemove', (e) => {
      const rect = c.getBoundingClientRect();
      const sx = e.clientX - rect.left;
      const sy = e.clientY - rect.top;
      if (sx >= 0 && sx <= c.width && sy >= 0 && sy <= c.height) {
        const w = this.screenToWorld(sx, sy);
        coordLbl.innerText = 'X: ' + w.x.toFixed(3) + ', Y: ' + w.y.toFixed(3);
      }

      if (this.isPanning) {
        this.panX = e.clientX - this.startX;
        this.panY = e.clientY - this.startY;
        this.render();
      } else if (this.isDragging && this.dragStartPoints.size > 0) {
        const curMouse = this.screenToWorld(sx, sy);
        const dx = curMouse.x - this.dragStartMouse.x;
        const dy = curMouse.y - this.dragStartMouse.y;

        this.dragStartPoints.forEach((initPos, sIdx) => {
          const pt = CNCApp.State.points[sIdx];
          pt.x = parseFloat((initPos.x + dx).toFixed(3));
          pt.y = parseFloat((initPos.y + dy).toFixed(3));
          CNCApp.Table.updateRow(sIdx);
        });
        this.render();
      } else if (this.isBoxSelecting) {
        this.boxCurX = sx;
        this.boxCurY = sy;
        this.render();
      }
    });

    window.addEventListener('mouseup', () => {
      if (this.isDragging) {
        this.isDragging = false;
        this.draggedIndex = null;
        this.dragStartPoints.clear();
        CNCApp.State.snapshot();
      }
      if (this.isBoxSelecting) {
        this.isBoxSelecting = false;
        this.finishBoxSelect();
        this.render();
      }
      this.isPanning = false;
    });
  },

  finishBoxSelect: function() {
    const x1 = Math.min(this.boxStartX, this.boxCurX);
    const x2 = Math.max(this.boxStartX, this.boxCurX);
    const y1 = Math.min(this.boxStartY, this.boxCurY);
    const y2 = Math.max(this.boxStartY, this.boxCurY);

    if (Math.abs(x2 - x1) > 4 || Math.abs(y2 - y1) > 4) {
      CNCApp.State.points.forEach((p, idx) => {
        if (CNCApp.State.shadedDispensers && CNCApp.State.shadedDispensers.has(p.dispenser)) {
          return;
        }
        const sp = this.worldToScreen(p.x, p.y);
        if (sp.x >= x1 && sp.x <= x2 && sp.y >= y1 && sp.y <= y2) {
          CNCApp.State.selectedIndices.add(idx);
        }
      });
      CNCApp.Table.render();
    }
  },

  findHitPoint: function(wx, wy) {
    const threshold = 8 / this.scale;
    for (let i = CNCApp.State.points.length - 1; i >= 0; i--) {
      const p = CNCApp.State.points[i];
      if (CNCApp.State.shadedDispensers && CNCApp.State.shadedDispensers.has(p.dispenser)) {
        continue;
      }
      const dist = Math.hypot(p.x - wx, p.y - wy);
      if (dist <= threshold) return i;
    }
    return null;
  },

  render: function() {
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    ctx.clearRect(0, 0, w, h);

    this.drawGrid(5);

    if (CNCApp.State.svgImage) {
      const pos = this.worldToScreen(0, 0);
      const img = CNCApp.State.svgImage;
      const sw = (img.width || 100) * (this.scale / 3.7795);
      const sh = (img.height || 100) * (this.scale / 3.7795);
      ctx.globalAlpha = 0.45;
      ctx.drawImage(img, pos.x, pos.y - sh, sw, sh);
      ctx.globalAlpha = 1.0;
    }

    const pts = CNCApp.State.points;
    if (pts.length > 1) {
      ctx.beginPath();
      ctx.strokeStyle = "#94a3b8";
      ctx.lineWidth = 1.2;
      let started = false;
      for (let p of pts) {
        if (!p.active) continue;
        if (CNCApp.State.shadedDispensers && CNCApp.State.shadedDispensers.has(p.dispenser)) continue;
        const sp = this.worldToScreen(p.x, p.y);
        if (!started) { ctx.moveTo(sp.x, sp.y); started = true; }
        else { ctx.lineTo(sp.x, sp.y); }
      }
      ctx.stroke();
    }

    pts.forEach((p, idx) => {
      const sp = this.worldToScreen(p.x, p.y);
      const isSel = CNCApp.State.selectedIndices.has(idx);
      const isAct = CNCApp.State.activePointIndex === idx;
      const isShaded = CNCApp.State.shadedDispensers && CNCApp.State.shadedDispensers.has(p.dispenser);

      const disp = CNCApp.State.machine.dispensers.find(d => d.id === p.dispenser) || { color: '#2563eb' };
      ctx.fillStyle = disp.color;

      ctx.beginPath();
      ctx.arc(sp.x, sp.y, isSel ? 6 : 4, 0, Math.PI * 2);

      if (isShaded) {
        ctx.globalAlpha = 0.12;
      } else {
        ctx.globalAlpha = p.active ? 1.0 : 0.35;
      }
      ctx.fill();
      ctx.globalAlpha = 1.0;

      // Приказ на безбедносен радиус (клиренс до ѕид) за автоматски пресметани точки
      if (CNCApp.State.showClearanceRings && p.clearance && p.clearance > 0 && !isShaded) {
        ctx.save();
        ctx.beginPath();
        ctx.arc(sp.x, sp.y, p.clearance * this.scale, 0, Math.PI * 2);
        ctx.strokeStyle = isSel ? "rgba(37, 99, 235, 0.75)" : "rgba(16, 185, 129, 0.35)";
        ctx.lineWidth = isSel ? 1.5 : 1;
        ctx.setLineDash([3, 3]);
        ctx.stroke();
        ctx.restore();
      }

      if (!isShaded) {
        if (isSel) {
          ctx.strokeStyle = "#0f172a";
          ctx.lineWidth = 2;
          ctx.stroke();
        }
        if (isAct) {
          ctx.strokeStyle = "#2563eb";
          ctx.lineWidth = 1.8;
          ctx.beginPath();
          ctx.arc(sp.x, sp.y, 10, 0, Math.PI * 2);
          ctx.stroke();
        }
      } else {
        ctx.strokeStyle = "#cbd5e1";
        ctx.lineWidth = 1;
        ctx.globalAlpha = 0.25;
        ctx.stroke();
        ctx.globalAlpha = 1.0;
      }
    });

    if (this.isBoxSelecting) {
      const bx = Math.min(this.boxStartX, this.boxCurX);
      const by = Math.min(this.boxStartY, this.boxCurY);
      const bw = Math.abs(this.boxCurX - this.boxStartX);
      const bh = Math.abs(this.boxCurY - this.boxStartY);

      if (this.isAdditiveSelection) {
        ctx.fillStyle = "rgba(16, 185, 129, 0.18)";
        ctx.fillRect(bx, by, bw, bh);
        ctx.strokeStyle = "#059669";
        ctx.lineWidth = 1.2;
        ctx.setLineDash([4, 4]);
        ctx.strokeRect(bx, by, bw, bh);
        ctx.setLineDash([]);
      } else {
        ctx.fillStyle = "rgba(37, 99, 235, 0.15)";
        ctx.fillRect(bx, by, bw, bh);
        ctx.strokeStyle = "#2563eb";
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 4]);
        ctx.strokeRect(bx, by, bw, bh);
        ctx.setLineDash([]);
      }
    }
  },

  drawGrid: function(stepMm) {
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;
    ctx.strokeStyle = "#e2e8f0";
    ctx.lineWidth = 1;

    const start = this.screenToWorld(0, h);
    const end = this.screenToWorld(w, 0);

    const minX = Math.floor(start.x / stepMm) * stepMm;
    const maxX = Math.ceil(end.x / stepMm) * stepMm;
    const minY = Math.floor(start.y / stepMm) * stepMm;
    const maxY = Math.ceil(end.y / stepMm) * stepMm;

    ctx.beginPath();
    for (let x = minX; x <= maxX; x += stepMm) {
      const sx = this.worldToScreen(x, 0).x;
      ctx.moveTo(sx, 0); ctx.lineTo(sx, h);
    }
    for (let y = minY; y <= maxY; y += stepMm) {
      const sy = this.worldToScreen(0, y).y;
      ctx.moveTo(0, sy); ctx.lineTo(w, sy);
    }
    ctx.stroke();

    const zero = this.worldToScreen(0, 0);
    ctx.strokeStyle = "#64748b";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(zero.x, 0); ctx.lineTo(zero.x, h);
    ctx.moveTo(0, zero.y); ctx.lineTo(w, zero.y);
    ctx.stroke();
  }
};