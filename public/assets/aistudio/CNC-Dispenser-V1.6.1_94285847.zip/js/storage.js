window.CNCApp = window.CNCApp || {};

CNCApp.Storage = {
  KEY: "CNC_DISPENSER_V161_AUTOSAVE",

  saveAutoSave: function() {
    try {
      const data = {
        points: CNCApp.State.points,
        header: CNCApp.State.header,
        footer: CNCApp.State.footer,
        svgData: CNCApp.State.svgData,
        machine: CNCApp.State.machine,
        stepIncrement: CNCApp.State.stepIncrement
      };
      localStorage.setItem(this.KEY, JSON.stringify(data));
    } catch(e) {}
  },

  loadAutoSave: function() {
    try {
      const raw = localStorage.getItem(this.KEY);
      if (!raw) return false;
      const data = JSON.parse(raw);
      if (data.points && data.points.length > 0) {
        CNCApp.State.points = data.points;
        CNCApp.State.header = data.header || '';
        CNCApp.State.footer = data.footer || 'G28.1 X2 Y2;M5;M30';
        if (data.machine) CNCApp.State.machine = data.machine;
        if (data.stepIncrement) CNCApp.State.stepIncrement = data.stepIncrement;
        if (data.svgData) CNCApp.Parser.loadSvgContent(data.svgData);
        return true;
      }
    } catch(e) {}
    return false;
  }
};