window.CNCApp = window.CNCApp || {};

CNCApp.Table = {
  dragSourceIndex: null,

  render: function() {
    const tb = document.getElementById('tableBody');
    tb.innerHTML = '';
    const pts = CNCApp.State.points;
    const countBadge = document.getElementById('selectedCount');
    countBadge.innerText = 'Селектирани: ' + CNCApp.State.selectedIndices.size;
    const step = CNCApp.State.stepIncrement || 0.05;

    pts.forEach((p, idx) => {
      const tr = document.createElement('tr');
      tr.id = 'row-' + idx;
      tr.dataset.index = idx;
      if (CNCApp.State.selectedIndices.has(idx)) tr.classList.add('selected');
      if (CNCApp.State.activePointIndex === idx) tr.classList.add('active-focus');
      if (!p.active) tr.classList.add('inactive-row');

      tr.innerHTML = `
        <td class="drag-handle" draggable="true" title="Повлечи за прередување">☰</td>
        <td><input type="checkbox" ${p.active ? 'checked' : ''} onchange="CNCApp.Table.updateField(${idx}, 'active', this.checked)"></td>
        <td>${idx + 1}</td>
        <td><input type="number" step="${step}" value="${p.x.toFixed(3)}" onchange="CNCApp.Table.updateField(${idx}, 'x', parseFloat(parseFloat(this.value).toFixed(3)))"></td>
        <td><input type="number" step="${step}" value="${p.y.toFixed(3)}" onchange="CNCApp.Table.updateField(${idx}, 'y', parseFloat(parseFloat(this.value).toFixed(3)))"></td>
        <td><input type="number" value="${Math.round(p.speed)}" onchange="CNCApp.Table.updateField(${idx}, 'speed', Math.round(parseFloat(this.value) || 1000))"></td>
        <td><input type="checkbox" ${p.lower ? 'checked' : ''} onchange="CNCApp.Table.updateField(${idx}, 'lower', this.checked)"></td>
        <td><input type="checkbox" ${p.valveStart ? 'checked' : ''} onchange="CNCApp.Table.updateField(${idx}, 'valveStart', this.checked)"></td>
        <td><input type="number" value="${p.time !== '' ? Math.round(p.time) : ''}" placeholder="" style="width:42px" onchange="CNCApp.Table.updateField(${idx}, 'time', this.value !== '' ? Math.round(parseFloat(this.value)) : '')"></td>
        <td><input type="checkbox" ${p.valveStop ? 'checked' : ''} onchange="CNCApp.Table.updateField(${idx}, 'valveStop', this.checked)"></td>
        <td><input type="checkbox" ${p.raise ? 'checked' : ''} onchange="CNCApp.Table.updateField(${idx}, 'raise', this.checked)"></td>
        <td>
          <select onchange="CNCApp.Table.updateField(${idx}, 'dispenser', parseInt(this.value))">
            ${CNCApp.State.machine.dispensers.map(d => `<option value="${d.id}" ${p.dispenser === d.id ? 'selected' : ''}>${d.name}</option>`).join('')}
          </select>
        </td>
        <td><input type="text" value="${p.group1}" onchange="CNCApp.Table.updateField(${idx}, 'group1', this.value)"></td>
        <td><input type="text" value="${p.group2}" onchange="CNCApp.Table.updateField(${idx}, 'group2', this.value)"></td>
      `;

      const handle = tr.querySelector('.drag-handle');
      handle.addEventListener('dragstart', (e) => {
        CNCApp.Table.dragSourceIndex = idx;
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/plain', idx);
      });

      tr.addEventListener('dragover', (e) => {
        e.preventDefault();
        tr.classList.add('drag-over');
      });

      tr.addEventListener('dragleave', () => {
        tr.classList.remove('drag-over');
      });

      tr.addEventListener('drop', (e) => {
        e.preventDefault();
        tr.classList.remove('drag-over');
        const fromIdx = CNCApp.Table.dragSourceIndex;
        const toIdx = idx;
        if (fromIdx !== null && fromIdx !== toIdx) {
          CNCApp.Table.moveRow(fromIdx, toIdx);
        }
      });

      tr.addEventListener('click', (e) => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT' || e.target.classList.contains('drag-handle')) return;

        if (e.shiftKey && CNCApp.State.lastSelectedRowIndex !== null) {
          const start = Math.min(CNCApp.State.lastSelectedRowIndex, idx);
          const end = Math.max(CNCApp.State.lastSelectedRowIndex, idx);
          if (!e.ctrlKey) CNCApp.State.selectedIndices.clear();
          for (let r = start; r <= end; r++) {
            CNCApp.State.selectedIndices.add(r);
          }
        } else {
          if (!e.ctrlKey) CNCApp.State.selectedIndices.clear();
          CNCApp.State.selectedIndices.add(idx);
          CNCApp.State.lastSelectedRowIndex = idx;
        }

        CNCApp.State.activePointIndex = idx;
        CNCApp.Table.render();
        CNCApp.Canvas.render();
      });

      tb.appendChild(tr);
    });

    CNCApp.GCode.updateCycleTime();
    CNCApp.Table.updateGroupDropdown();
  },

  moveRow: function(fromIdx, toIdx) {
    const moved = CNCApp.State.points.splice(fromIdx, 1)[0];
    CNCApp.State.points.splice(toIdx, 0, moved);

    CNCApp.State.selectedIndices.clear();
    CNCApp.State.selectedIndices.add(toIdx);
    CNCApp.State.activePointIndex = toIdx;
    CNCApp.State.lastSelectedRowIndex = toIdx;

    CNCApp.State.snapshot();
    this.render();
    CNCApp.Canvas.render();
    this.scrollToRow(toIdx);
  },

  moveSelectedUp: function() {
    const sel = Array.from(CNCApp.State.selectedIndices).sort((a, b) => a - b);
    if (sel.length === 0 || sel[0] === 0) return;

    sel.forEach(idx => {
      const temp = CNCApp.State.points[idx - 1];
      CNCApp.State.points[idx - 1] = CNCApp.State.points[idx];
      CNCApp.State.points[idx] = temp;
    });

    const newSel = new Set(sel.map(i => i - 1));
    CNCApp.State.selectedIndices = newSel;
    if (CNCApp.State.activePointIndex !== null && CNCApp.State.activePointIndex > 0) {
      CNCApp.State.activePointIndex--;
    }

    CNCApp.State.snapshot();
    this.render();
    CNCApp.Canvas.render();
    this.scrollToRow(Array.from(newSel)[0]);
  },

  moveSelectedDown: function() {
    const sel = Array.from(CNCApp.State.selectedIndices).sort((a, b) => b - a);
    if (sel.length === 0 || sel[0] >= CNCApp.State.points.length - 1) return;

    sel.forEach(idx => {
      const temp = CNCApp.State.points[idx + 1];
      CNCApp.State.points[idx + 1] = CNCApp.State.points[idx];
      CNCApp.State.points[idx] = temp;
    });

    const newSel = new Set(sel.map(i => i + 1));
    CNCApp.State.selectedIndices = newSel;
    if (CNCApp.State.activePointIndex !== null && CNCApp.State.activePointIndex < CNCApp.State.points.length - 1) {
      CNCApp.State.activePointIndex++;
    }

    CNCApp.State.snapshot();
    this.render();
    CNCApp.Canvas.render();
    this.scrollToRow(Array.from(newSel)[0]);
  },

  updateField: function(idx, field, val) {
    CNCApp.State.points[idx][field] = val;
    CNCApp.State.snapshot();
    CNCApp.Canvas.render();
    CNCApp.GCode.updateCycleTime();
    if (field === 'group1' || field === 'group2') {
      CNCApp.Table.updateGroupDropdown();
    }
  },

  updateRow: function(idx) {
    const tr = document.getElementById('row-' + idx);
    if (!tr) return;
    const inputs = tr.querySelectorAll('input');
    inputs[1].value = CNCApp.State.points[idx].x.toFixed(3);
    inputs[2].value = CNCApp.State.points[idx].y.toFixed(3);
  },

  scrollToRow: function(idx) {
    const tr = document.getElementById('row-' + idx);
    if (tr) tr.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  },

  insertNewPointAt: function(x, y) {
    const pt = CNCApp.State.createPoint(x, y);
    let targetIdx = CNCApp.State.points.length;
    if (CNCApp.State.activePointIndex !== null && CNCApp.State.activePointIndex < CNCApp.State.points.length) {
      targetIdx = CNCApp.State.activePointIndex + 1;
      CNCApp.State.points.splice(targetIdx, 0, pt);
    } else {
      CNCApp.State.points.push(pt);
    }
    CNCApp.State.activePointIndex = targetIdx;
    CNCApp.State.selectedIndices.clear();
    CNCApp.State.selectedIndices.add(targetIdx);
    CNCApp.State.lastSelectedRowIndex = targetIdx;
    CNCApp.State.snapshot();
    this.render();
    CNCApp.Canvas.render();
    this.scrollToRow(targetIdx);
  },

  updateGroupDropdown: function() {
    const sel = document.getElementById('selByGroup');
    if (!sel) return;
    const curVal = sel.value;
    const groups = new Set();
    CNCApp.State.points.forEach(p => {
      if (p.group1 && p.group1.trim()) groups.add(p.group1.trim());
      if (p.group2 && p.group2.trim()) groups.add(p.group2.trim());
    });

    sel.innerHTML = '<option value="">-- Избери група --</option>';
    if (groups.size === 0) {
      sel.innerHTML = '<option value="">-- Нема групи --</option>';
    } else {
      Array.from(groups).sort().forEach(g => {
        sel.innerHTML += `<option value="${g}">${g}</option>`;
      });
    }
    sel.value = curVal;
  }
};