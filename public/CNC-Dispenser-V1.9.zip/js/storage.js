window.CNCApp = window.CNCApp || {};

CNCApp.Storage = {
  KEY: "CNC_DISPENSER_V19_STORAGE",

  saveAutoSave: function() {
    try {
      const data = {
        projectName: CNCApp.State.projectName || 'Нов проект.csv',
        isDirty: !!CNCApp.State.isDirty,
        points: CNCApp.State.points,
        header: CNCApp.State.header,
        footer: CNCApp.State.footer,
        svgData: CNCApp.State.svgData,
        machine: CNCApp.State.machine,
        stepIncrement: CNCApp.State.stepIncrement
      };
      localStorage.setItem(this.KEY, JSON.stringify(data));
    } catch(e) {}
  },

  loadAutoSave: function() {
    try {
      const raw = localStorage.getItem(this.KEY) || localStorage.getItem("CNC_DISPENSER_V185_STORAGE") || localStorage.getItem("CNC_DISPENSER_V161_AUTOSAVE");
      if (!raw) return false;
      const data = JSON.parse(raw);
      if (data.points && data.points.length > 0) {
        CNCApp.State.points = data.points;
        CNCApp.State.header = data.header || '';
        if (data.projectName) CNCApp.State.projectName = data.projectName;
        CNCApp.State.isDirty = !!data.isDirty;
        
        // Автоматска миграција на футерот кон новиот 4-реден стандард
        if (!data.footer || data.footer === 'G28.1 X2 Y2;M5;M30' || !data.footer.includes('G1 X1 Y1 F2000')) {
          CNCApp.State.footer = "G28.1 X2 Y2\r\nG1 X1 Y1 F2000\r\nM5\r\nM30";
        } else {
          CNCApp.State.footer = data.footer;
        }

        // Автоматска миграција на офсетите кон калибрираните вредности: D1: -0.3, 34.45 (+40mm)
        if (data.machine && Array.isArray(data.machine.dispensers)) {
          const d1 = data.machine.dispensers[0];
          if (d1 && (d1.offsetX === 0.8 || d1.offsetX === -0.4 || d1.offsetY === 36 || d1.offsetY === 34.55)) {
            data.machine.dispensers = [
              { id: 1, name: "Боја 1", color: "#2563eb", lowerCmd: "M104", raiseCmd: "M204", offsetX: -0.30, offsetY: 34.45 },
              { id: 2, name: "Боја 2", color: "#059669", lowerCmd: "M105", raiseCmd: "M205", offsetX: 39.70, offsetY: 34.45 },
              { id: 3, name: "Боја 3", color: "#dc2626", lowerCmd: "M106", raiseCmd: "M206", offsetX: 79.70, offsetY: 34.45 },
              { id: 4, name: "Боја 4", color: "#d97706", lowerCmd: "M107", raiseCmd: "M207", offsetX: 119.70, offsetY: 34.45 },
              { id: 5, name: "Боја 5", color: "#7c3aed", lowerCmd: "M108", raiseCmd: "M208", offsetX: 159.70, offsetY: 34.45 }
            ];
          }
          CNCApp.State.machine = data.machine;
        }

        if (data.stepIncrement) CNCApp.State.stepIncrement = data.stepIncrement;
        if (data.svgData) CNCApp.Parser.loadSvgContent(data.svgData);
        if (data.projectName) CNCApp.State.projectName = data.projectName;
        CNCApp.State.isDirty = !!data.isDirty;
        if (typeof CNCApp.State.updateProjectUI === 'function') CNCApp.State.updateProjectUI();
        return true;
      }
    } catch(e) {}
    return false;
  }
};