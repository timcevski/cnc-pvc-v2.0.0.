window.CNCApp = window.CNCApp || {};

document.addEventListener('DOMContentLoaded', function() {
  CNCApp.Canvas.init();

  function renderCanvasDispenserFilters() {
    const container = document.getElementById('dispenserFilterButtons');
    if (!container) return;
    container.innerHTML = '';
    CNCApp.State.shadedDispensers = CNCApp.State.shadedDispensers || new Set();

    CNCApp.State.machine.dispensers.forEach(d => {
      const isShaded = CNCApp.State.shadedDispensers.has(d.id);
      const btn = document.createElement('button');
      btn.className = 'btn btn-xs';
      btn.style.display = 'inline-flex';
      btn.style.alignItems = 'center';
      btn.style.gap = '3px';
      btn.style.padding = '1px 6px';
      btn.style.fontSize = '10.5px';
      btn.style.fontWeight = '600';
      btn.style.cursor = 'pointer';
      btn.style.transition = '0.15s';
      btn.title = `Клик: вклучи/исклучи (shade) за ${d.name}. Alt+Клик: изолирај само овој диспензер.`;

      if (isShaded) {
        btn.style.background = '#f1f5f9';
        btn.style.color = '#94a3b8';
        btn.style.borderColor = '#cbd5e1';
        btn.style.opacity = '0.6';
        btn.style.textDecoration = 'line-through';
        btn.innerHTML = `<span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#cbd5e1;"></span>${d.name}`;
      } else {
        btn.style.background = '#ffffff';
        btn.style.color = '#0f172a';
        btn.style.borderColor = d.color;
        btn.style.boxShadow = `0 1px 2px rgba(0,0,0,0.05)`;
        btn.innerHTML = `<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:${d.color};"></span>${d.name}`;
      }

      btn.onclick = (e) => {
        if (e.altKey) {
          CNCApp.State.shadedDispensers.clear();
          CNCApp.State.machine.dispensers.forEach(otherD => {
            if (otherD.id !== d.id) CNCApp.State.shadedDispensers.add(otherD.id);
          });
        } else {
          if (CNCApp.State.shadedDispensers.has(d.id)) {
            CNCApp.State.shadedDispensers.delete(d.id);
          } else {
            CNCApp.State.shadedDispensers.add(d.id);
          }
        }
        renderCanvasDispenserFilters();
        CNCApp.Canvas.render();
      };

      container.appendChild(btn);
    });

    if (CNCApp.State.shadedDispensers.size > 0) {
      const btnAll = document.createElement('button');
      btnAll.className = 'btn btn-xs';
      btnAll.style.fontSize = '10px';
      btnAll.style.padding = '1px 5px';
      btnAll.style.color = '#2563eb';
      btnAll.style.fontWeight = 'bold';
      btnAll.innerText = 'Сите';
      btnAll.title = 'Прикажи ги сите диспензери одеднаш';
      btnAll.onclick = () => {
        CNCApp.State.shadedDispensers.clear();
        renderCanvasDispenserFilters();
        CNCApp.Canvas.render();
      };
      container.appendChild(btnAll);
    }
  }

  const btnToggleSvg = document.getElementById('btnToggleSvg');
  function updateSvgToggleUI() {
    if (!btnToggleSvg) return;
    const isVisible = CNCApp.State.showSvg !== false;
    btnToggleSvg.style.display = 'inline-flex';
    btnToggleSvg.style.alignItems = 'center';
    btnToggleSvg.style.gap = '3px';
    btnToggleSvg.style.padding = '1px 6px';
    btnToggleSvg.style.fontSize = '10.5px';
    btnToggleSvg.style.fontWeight = '600';
    btnToggleSvg.style.cursor = 'pointer';
    btnToggleSvg.style.transition = '0.15s';

    if (isVisible) {
      btnToggleSvg.style.background = '#ffffff';
      btnToggleSvg.style.color = '#1e293b';
      btnToggleSvg.style.borderColor = '#6366f1';
      btnToggleSvg.style.boxShadow = '0 1px 2px rgba(0,0,0,0.05)';
      btnToggleSvg.style.opacity = '1.0';
      btnToggleSvg.style.textDecoration = 'none';
      btnToggleSvg.innerHTML = '<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:#6366f1;"></span>🖼️ SVG';
      btnToggleSvg.title = 'Клик: исклучи приказ на SVG подлогата на графикот';
    } else {
      btnToggleSvg.style.background = '#f1f5f9';
      btnToggleSvg.style.color = '#94a3b8';
      btnToggleSvg.style.borderColor = '#cbd5e1';
      btnToggleSvg.style.boxShadow = 'none';
      btnToggleSvg.style.opacity = '0.6';
      btnToggleSvg.style.textDecoration = 'line-through';
      btnToggleSvg.innerHTML = '<span style="display:inline-block;width:6px;height:6px;border-radius:50%;background:#cbd5e1;"></span>🖼️ SVG';
      btnToggleSvg.title = 'Клик: вклучи приказ на SVG подлогата на графикот';
    }
  }
  CNCApp.updateSvgToggleUI = updateSvgToggleUI;

  if (btnToggleSvg) {
    btnToggleSvg.onclick = () => {
      CNCApp.State.showSvg = (CNCApp.State.showSvg === false) ? true : false;
      updateSvgToggleUI();
      CNCApp.Canvas.render();
    };
    updateSvgToggleUI();
  }

  function populateDispenserSelectors() {
    const bColor = document.getElementById('batchColor');
    const selColor = document.getElementById('selByColor');
    bColor.innerHTML = '<option value="">-- Избери --</option>';
    selColor.innerHTML = '<option value="">-- По боја --</option>';
    CNCApp.State.machine.dispensers.forEach(d => {
      bColor.innerHTML += `<option value="${d.id}">${d.name}</option>`;
      selColor.innerHTML += `<option value="${d.id}">${d.name}</option>`;
    });
    renderCanvasDispenserFilters();
  }
  populateDispenserSelectors();

  if (!CNCApp.Storage.loadAutoSave()) {
    CNCApp.State.points.push(CNCApp.State.createPoint(10, 10));
    CNCApp.State.points.push(CNCApp.State.createPoint(25, 20));
    CNCApp.State.points.push(CNCApp.State.createPoint(35, 10));
    CNCApp.State.snapshot();
  }
  CNCApp.Table.render();
  CNCApp.Canvas.resetView();

  window.addEventListener('keydown', (e) => {
    const tag = document.activeElement ? document.activeElement.tagName : '';
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    if (CNCApp.State.selectedIndices.size === 0) return;

    const step = CNCApp.State.stepIncrement || 0.05;
    let dx = 0, dy = 0;
    if (e.key === 'ArrowUp') dy = step;
    else if (e.key === 'ArrowDown') dy = -step;
    else if (e.key === 'ArrowLeft') dx = -step;
    else if (e.key === 'ArrowRight') dx = step;
    else return;

    e.preventDefault();
    CNCApp.State.selectedIndices.forEach(idx => {
      const p = CNCApp.State.points[idx];
      p.x = parseFloat((p.x + dx).toFixed(3));
      p.y = parseFloat((p.y + dy).toFixed(3));
      CNCApp.Table.updateRow(idx);
    });

    CNCApp.Canvas.render();
    CNCApp.State.snapshot();
  });

  const btnToggleAdd = document.getElementById('btnToggleAddMode');
  function updateAddModeUI() {
    if (CNCApp.State.isAddMode) {
      btnToggleAdd.innerText = "➕ Точка: ВКЛ";
      btnToggleAdd.className = "btn btn-xs btn-addmode-on";
    } else {
      btnToggleAdd.innerText = "➕ Точка: ИСКЛ";
      btnToggleAdd.className = "btn btn-xs btn-addmode-off";
    }
  }
  updateAddModeUI();
  btnToggleAdd.onclick = () => {
    CNCApp.State.isAddMode = !CNCApp.State.isAddMode;
    updateAddModeUI();
  };

  document.getElementById('btnResetView').onclick = () => {
    CNCApp.Canvas.resetView();
  };

  document.getElementById('btnClearSvg').onclick = () => {
    CNCApp.State.svgData = null;
    CNCApp.State.svgImage = null;
    if (typeof CNCApp.updateSvgToggleUI === 'function') CNCApp.updateSvgToggleUI();
    CNCApp.Canvas.render();
  };

  const btnToggleClearance = document.getElementById('btnToggleClearance');
  if (btnToggleClearance) {
    btnToggleClearance.onclick = () => {
      CNCApp.State.showClearanceRings = !CNCApp.State.showClearanceRings;
      if (CNCApp.State.showClearanceRings) {
        btnToggleClearance.innerText = "⭕ Клиренс: ВКЛ";
        btnToggleClearance.style.background = "#f0fdf4";
        btnToggleClearance.style.color = "#166534";
      } else {
        btnToggleClearance.innerText = "⭕ Клиренс: ИСКЛ";
        btnToggleClearance.style.background = "#f1f5f9";
        btnToggleClearance.style.color = "#64748b";
      }
      CNCApp.Canvas.render();
    };
  }

  document.getElementById('btnAddPoint').onclick = () => {
    CNCApp.Table.insertNewPointAt(20, 20);
  };

  const btnDemo = document.getElementById('btnQuickDemoPattern');
  if (btnDemo) {
    btnDemo.onclick = () => {
      CNCApp.State.points = [
        { active: true, x: 10, y: 10, speed: 1200, lower: true, valveStart: true, time: 200, valveStop: true, raise: true, dispenser: 1, group1: "Тест", group2: "Капка" },
        { active: true, x: 25, y: 10, speed: 1200, lower: true, valveStart: true, time: 200, valveStop: true, raise: true, dispenser: 1, group1: "Тест", group2: "Капка" },
        { active: true, x: 40, y: 25, speed: 1000, lower: true, valveStart: true, time: 250, valveStop: true, raise: true, dispenser: 2, group1: "Тест", group2: "Капка" },
        { active: true, x: 40, y: 40, speed: 1000, lower: true, valveStart: true, time: 250, valveStop: true, raise: true, dispenser: 2, group1: "Тест", group2: "Капка" },
        { active: true, x: 25, y: 55, speed: 1500, lower: true, valveStart: true, time: 180, valveStop: true, raise: true, dispenser: 3, group1: "Тест", group2: "Капка" },
        { active: true, x: 10, y: 40, speed: 1500, lower: true, valveStart: true, time: 180, valveStop: true, raise: true, dispenser: 3, group1: "Тест", group2: "Капка" },
        { active: true, x: 25, y: 25, speed: 800, lower: true, valveStart: true, time: 350, valveStop: true, raise: true, dispenser: 1, group1: "Центар", group2: "Капка" }
      ];
      CNCApp.State.selectedIndices.clear();
      CNCApp.State.activePointIndex = 0;
      CNCApp.State.selectedIndices.add(0);
      CNCApp.State.snapshot();
      CNCApp.Table.render();
      CNCApp.Canvas.resetView();
      alert("⭐ Вчитана е тест шема со 7 точки и 3 различни диспензери! Забележете како автоматски се ажурираа табелата, патеките на 2D платното и времето за циклус.");
    };
  }

  document.getElementById('btnMoveUp').onclick = () => CNCApp.Table.moveSelectedUp();
  document.getElementById('btnMoveDown').onclick = () => CNCApp.Table.moveSelectedDown();

  document.getElementById('btnDeleteSelected').onclick = () => {
    const sel = CNCApp.State.selectedIndices;
    if (sel.size === 0) return;
    CNCApp.State.points = CNCApp.State.points.filter((_, idx) => !sel.has(idx));
    sel.clear();
    CNCApp.State.activePointIndex = null;
    CNCApp.State.lastSelectedRowIndex = null;
    CNCApp.State.snapshot();
    CNCApp.Table.render();
    CNCApp.Canvas.render();
  };

  document.getElementById('btnUndo').onclick = () => CNCApp.State.undo();
  document.getElementById('btnRedo').onclick = () => CNCApp.State.redo();

  document.getElementById('btnApplyBatchValues').onclick = () => {
    const sel = CNCApp.State.selectedIndices;
    if (sel.size === 0) return;

    const bColor = document.getElementById('batchColor');
    const bSpeed = document.getElementById('batchSpeed');
    const bTime = document.getElementById('batchTime');
    const bOffsetX = document.getElementById('batchOffsetX');
    const bOffsetY = document.getElementById('batchOffsetY');
    const bGroup1 = document.getElementById('batchGroup1');
    const bGroup2 = document.getElementById('batchGroup2');

    const col = parseInt(bColor.value);
    const spd = parseFloat(bSpeed.value);
    const tm = bTime.value !== '' ? parseFloat(bTime.value) : null;
    const ox = parseFloat(bOffsetX.value) || 0;
    const oy = parseFloat(bOffsetY.value) || 0;
    const g1 = bGroup1.value;
    const g2 = bGroup2.value;

    sel.forEach(idx => {
      const p = CNCApp.State.points[idx];
      if (col) p.dispenser = col;
      if (!isNaN(spd) && spd > 0) p.speed = Math.round(spd);
      if (tm !== null) p.time = Math.round(tm);
      if (ox !== 0) p.x = parseFloat((p.x + ox).toFixed(3));
      if (oy !== 0) p.y = parseFloat((p.y + oy).toFixed(3));
      if (g1) p.group1 = g1;
      if (g2) p.group2 = g2;
    });

    bColor.value = '';
    bSpeed.value = '';
    bTime.value = '';
    bOffsetX.value = '0';
    bOffsetY.value = '0';
    bGroup1.value = '';
    bGroup2.value = '';

    CNCApp.State.snapshot();
    CNCApp.Table.render();
    CNCApp.Canvas.render();
  };

  const btnLine = document.getElementById('btnPresetLine');
  if (btnLine) {
    btnLine.onclick = () => {
      const sel = Array.from(CNCApp.State.selectedIndices).sort((a, b) => a - b);
      if (sel.length < 2) {
        alert("⚠️ За да формирате линија, потребно е да селектирате минимум 2 последователни точки.");
        return;
      }

      // БЕЗБЕДНОСНА ПРОВЕРКА 1: Сите точки мора да припаѓаат на ист диспензер (иста боја)
      const firstDisp = CNCApp.State.points[sel[0]].dispenser;
      const hasMixedDispensers = sel.some(idx => CNCApp.State.points[idx].dispenser !== firstDisp);
      if (hasMixedDispensers) {
        alert("⛔ БЕЗБЕДНОСНА БЛОКАДА: Не може да се креира континуирана линија меѓу точки со различни бои/диспензери!\n\nСите селектирани точки мора да припаѓаат на ИСТ диспензер. За премин на друг диспензер, машината мора задолжително да го подигне алатот (Горе) за да се спречи судир или влечење на боја по материјалот.");
        return;
      }

      // БЕЗБЕДНОСНА ПРОВЕРКА 2: Точките мора да бидат строго последователни во табелата
      for (let i = 0; i < sel.length - 1; i++) {
        if (sel[i + 1] !== sel[i] + 1) {
          alert("⚠️ БЕЗБЕДНОСНА ПРОВЕРКА: Селектираните точки мора да бидат строго последователни во табелата (без прескокнување редови).");
          return;
        }
      }

      sel.forEach((idx, i) => {
        const p = CNCApp.State.points[idx];
        p.active = true;
        if (i === 0) {
          p.lower = true;
          p.valveStart = true;
          p.valveStop = false;
          p.raise = false;
        } else if (i === sel.length - 1) {
          p.lower = false;
          p.valveStart = false;
          p.valveStop = true;
          p.raise = true;
        } else {
          p.lower = false;
          p.valveStart = false;
          p.valveStop = false;
          p.raise = false;
        }
      });

      CNCApp.Table.enforceDispenserSafety();
      CNCApp.State.snapshot();
      CNCApp.Table.render();
      CNCApp.Canvas.render();
      CNCApp.GCode.updateCycleTime();
    };
  }

  document.getElementById('btnSpeedPlus5').onclick = () => scaleField('speed', 1.05);
  document.getElementById('btnSpeedMinus5').onclick = () => scaleField('speed', 0.95);
  document.getElementById('btnTimePlus5').onclick = () => scaleField('time', 1.05);
  document.getElementById('btnTimeMinus5').onclick = () => scaleField('time', 0.95);

  function scaleField(fld, factor) {
    const sel = CNCApp.State.selectedIndices;
    if (sel.size === 0) return;
    sel.forEach(idx => {
      let v = parseFloat(CNCApp.State.points[idx][fld]) || 0;
      if (v > 0) {
        CNCApp.State.points[idx][fld] = Math.round(v * factor);
      }
    });
    CNCApp.State.snapshot();
    CNCApp.Table.render();
  }

  document.getElementById('btnSelectAll').onclick = () => {
    CNCApp.State.points.forEach((_, idx) => CNCApp.State.selectedIndices.add(idx));
    CNCApp.Table.render();
    CNCApp.Canvas.render();
  };
  document.getElementById('btnDeselectAll').onclick = () => {
    CNCApp.State.selectedIndices.clear();
    CNCApp.Table.render();
    CNCApp.Canvas.render();
  };
  document.getElementById('btnInvertSelect').onclick = () => {
    const cur = new Set(CNCApp.State.selectedIndices);
    CNCApp.State.selectedIndices.clear();
    CNCApp.State.points.forEach((_, idx) => {
      if (!cur.has(idx)) CNCApp.State.selectedIndices.add(idx);
    });
    CNCApp.Table.render();
    CNCApp.Canvas.render();
  };
  document.getElementById('selByColor').onchange = (e) => {
    const val = parseInt(e.target.value);
    if (!val) return;
    CNCApp.State.selectedIndices.clear();
    CNCApp.State.points.forEach((p, idx) => {
      if (p.dispenser === val) CNCApp.State.selectedIndices.add(idx);
    });
    CNCApp.Table.render();
    CNCApp.Canvas.render();
  };
  document.getElementById('selByGroup').onchange = (e) => {
    const txt = e.target.value;
    if (!txt) return;
    CNCApp.State.selectedIndices.clear();
    CNCApp.State.points.forEach((p, idx) => {
      if (p.group1 === txt || p.group2 === txt) CNCApp.State.selectedIndices.add(idx);
    });
    CNCApp.Table.render();
    CNCApp.Canvas.render();
  };

  document.getElementById('cycleTimeBox').onclick = () => {
    const t = CNCApp.GCode.telemetry;
    const mTotal = Math.floor(t.totalSec / 60);
    const sTotal = Math.round(t.totalSec % 60);
    const mMove = Math.floor(t.travelSec / 60);
    const sMove = Math.round(t.travelSec % 60);
    const mDwell = Math.floor(t.dwellSec / 60);
    const sDwell = Math.round(t.dwellSec % 60);
    alert(`📊 Детална статистика на програмот:\n\n` +
          `⏱️ Вкупно време: ${mTotal}м ${sTotal}с\n` +
          `🚗 Време на движење со рампи: ${mMove}м ${sMove}с\n` +
          `💧 Време на дозирање + M-латенција: ${mDwell}м ${sDwell}с\n` +
          `📏 Вкупна физичка патека: ${(t.totalDistMm / 1000).toFixed(3)} метри`);
  };

  const fileInp = document.getElementById('fileInput');
  let currentFileMode = '';

  document.getElementById('btnOpenTxt').onclick = () => { currentFileMode = 'TXT'; fileInp.click(); };
  document.getElementById('btnOpenLegacyCsv').onclick = () => { currentFileMode = 'LEGACY_CSV'; fileInp.click(); };
  document.getElementById('btnOpenProjectCsv').onclick = () => { currentFileMode = 'PROJECT_CSV'; fileInp.click(); };
  document.getElementById('btnLoadSvg').onclick = () => { currentFileMode = 'SVG'; fileInp.click(); };

  fileInp.onchange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();

    if (currentFileMode === 'SVG') {
      reader.onload = (evt) => {
        const svgContent = evt.target.result;
        CNCApp.Parser.loadSvgContent(svgContent);
        if (CNCApp.SvgGenerator) {
          CNCApp.SvgGenerator.currentSvgString = svgContent;
          setTimeout(() => {
            if (confirm("Вчитан е SVG фајл! Дали сакате да го отворите волшебникот за автоматско генерирање на CNC патека со точки за диспензерите?")) {
              CNCApp.SvgGenerator.openModal(svgContent);
            }
          }, 150);
        }
      };
      reader.readAsText(file);
    } else {
      reader.onload = (evt) => {
        const txt = evt.target.result;
        if (currentFileMode === 'TXT') {
          CNCApp.State.points = CNCApp.Parser.parseTxt(txt);
        } else if (currentFileMode === 'LEGACY_CSV') {
          const res = CNCApp.Parser.parseLegacyCsv(txt);
          CNCApp.State.points = res.points;
          CNCApp.State.header = res.header;
          CNCApp.State.footer = res.footer;
        } else if (currentFileMode === 'PROJECT_CSV') {
          const res = CNCApp.Parser.parseProjectCsv(txt);
          CNCApp.State.points = res.points;
          CNCApp.State.header = res.header;
          CNCApp.State.footer = res.footer;
          if (res.svg) CNCApp.Parser.loadSvgContent(atob(res.svg));
          populateDispenserSelectors();
        }
        CNCApp.State.snapshot();
        CNCApp.Table.render();
        CNCApp.Canvas.resetView();
      };
      reader.readAsText(file);
    }
    fileInp.value = '';
  };

  document.getElementById('btnSaveProjectCsv').onclick = () => {
    const csvContent = CNCApp.Parser.exportProjectCsv();
    saveWithPicker(csvContent, 'cnc_project.csv', 'text/csv');
  };

  const btnExportAi = document.getElementById('btnExportForAi');
  if (btnExportAi) {
    btnExportAi.onclick = () => {
      const csvContent = CNCApp.Parser.exportProjectCsv();
      const numPts = CNCApp.State.points.length;
      const hasSvg = !!CNCApp.State.svgData;

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(csvContent).then(() => {
          alert(`✅ ИСКОПИРАНО ВО CLIPBOARD!\n\n` +
                `• Вкупно работни точки: ${numPts}\n` +
                `• SVG содржина: ${hasSvg ? 'ВКЛУЧЕНА во податоците' : 'Нема SVG'}\n\n` +
                `Сега само кликнете во полето за порака во разговорот со AI и притиснете Ctrl+V (Paste)!`);
        }).catch(() => {
          prompt("Ископирајте го кодот со Ctrl+A и Ctrl+C, па пастирајте го во чатот со AI:", csvContent);
        });
      } else {
        prompt("Ископирајте го кодот со Ctrl+A и Ctrl+C, па пастирајте го во чатот со AI:", csvContent);
      }
    };
  }

  document.getElementById('btnExportGcode').onclick = () => {
    const gcode = CNCApp.GCode.generate();
    saveWithPicker(gcode, 'dispenser_program.tap', 'text/plain');
  };

  async function saveWithPicker(content, defaultName, mime) {
    if (window.showSaveFilePicker) {
      try {
        const handle = await window.showSaveFilePicker({
          suggestedName: defaultName,
          types: [{ description: 'Фајл', accept: { [mime]: ['.' + defaultName.split('.').pop()] } }]
        });
        const writable = await handle.createWritable();
        await writable.write(content);
        await writable.close();
        return;
      } catch (err) {
        if (err.name === 'AbortError') return;
      }
    }
    const blob = new Blob([content], { type: mime });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = defaultName;
    a.click();
  }

  // ДИНАМИЧКИ ДИСПЕНЗЕРИ (1 ДО N)
  function renderSettingsDispensers() {
    const tb = document.getElementById('dispensersTableBody');
    tb.innerHTML = '';
    CNCApp.State.machine.dispensers.forEach((d, idx) => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td>${d.id}</td>
        <td><input type="text" value="${d.name}" class="inp inp-sm" style="width:70px"></td>
        <td><input type="color" value="${d.color}" style="width:30px;height:24px"></td>
        <td><input type="text" value="${d.lowerCmd}" class="inp inp-sm" style="width:55px"></td>
        <td><input type="text" value="${d.raiseCmd}" class="inp inp-sm" style="width:55px"></td>
        <td><input type="number" step="0.05" value="${d.offsetX}" class="inp inp-sm" style="width:55px"></td>
        <td><input type="number" step="0.05" value="${d.offsetY}" class="inp inp-sm" style="width:55px"></td>
        <td><button class="btn btn-xs btn-danger" onclick="CNCApp.App.deleteDispenser(${idx})">🗑️</button></td>
      `;
      tb.appendChild(tr);
    });
  }

  CNCApp.App = {
    renderCanvasDispenserFilters: renderCanvasDispenserFilters,
    deleteDispenser: function(index) {
      if (CNCApp.State.machine.dispensers.length <= 1) {
        alert("Мора да остане минимум 1 диспензер!");
        return;
      }
      CNCApp.State.machine.dispensers.splice(index, 1);
      renderSettingsDispensers();
    }
  };

  document.getElementById('btnAddDispenser').onclick = () => {
    const list = CNCApp.State.machine.dispensers;
    const nextId = list.length > 0 ? Math.max(...list.map(d => d.id)) + 1 : 1;
    const lastDisp = list[list.length - 1] || { offsetX: -39.2, offsetY: 36.0 };
    const palette = ["#2563eb", "#059669", "#dc2626", "#d97706", "#7c3aed", "#ec4899", "#06b6d4", "#84cc16"];
    const nextColor = palette[(nextId - 1) % palette.length];

    list.push({
      id: nextId,
      name: "Боја " + nextId,
      color: nextColor,
      lowerCmd: "M" + (103 + nextId),
      raiseCmd: "M" + (203 + nextId),
      offsetX: parseFloat((lastDisp.offsetX + 40.0).toFixed(3)),
      offsetY: lastDisp.offsetY
    });
    renderSettingsDispensers();
  };

  const modal = document.getElementById('settingsModal');
  document.getElementById('btnOpenSettings').onclick = () => {
    document.getElementById('modalHeaderCode').value = CNCApp.State.header;
    document.getElementById('modalFooterCode').value = CNCApp.State.footer;
    document.getElementById('modalTimeUnit').value = CNCApp.State.machine.timeUnit || 'ms';
    document.getElementById('modalDecimalSeparator').value = CNCApp.State.machine.decimalSeparator || '.';
    document.getElementById('modalMLatency').value = CNCApp.State.machine.mCommandLatency || 120;
    document.getElementById('modalDelayLower').value = CNCApp.State.machine.systemDelayLower;
    document.getElementById('modalDelayRaise').value = CNCApp.State.machine.systemDelayRaise;
    document.getElementById('modalStepIncrement').value = CNCApp.State.stepIncrement || 0.05;

    renderSettingsDispensers();
    modal.style.display = 'flex';
  };

  document.getElementById('btnCloseSettings').onclick = () => modal.style.display = 'none';

  document.getElementById('btnSaveSettings').onclick = () => {
    CNCApp.State.header = document.getElementById('modalHeaderCode').value;
    CNCApp.State.footer = document.getElementById('modalFooterCode').value;
    CNCApp.State.machine.timeUnit = document.getElementById('modalTimeUnit').value;
    CNCApp.State.machine.decimalSeparator = document.getElementById('modalDecimalSeparator').value;
    CNCApp.State.machine.mCommandLatency = parseInt(document.getElementById('modalMLatency').value) || 120;
    CNCApp.State.machine.systemDelayLower = parseInt(document.getElementById('modalDelayLower').value) || 150;
    CNCApp.State.machine.systemDelayRaise = parseInt(document.getElementById('modalDelayRaise').value) || 150;
    CNCApp.State.stepIncrement = parseFloat(document.getElementById('modalStepIncrement').value) || 0.05;

    const rows = document.querySelectorAll('#dispensersTableBody tr');
    rows.forEach((r, i) => {
      const inputs = r.querySelectorAll('input');
      CNCApp.State.machine.dispensers[i].name = inputs[0].value;
      CNCApp.State.machine.dispensers[i].color = inputs[1].value;
      CNCApp.State.machine.dispensers[i].lowerCmd = inputs[2].value;
      CNCApp.State.machine.dispensers[i].raiseCmd = inputs[3].value;
      CNCApp.State.machine.dispensers[i].offsetX = parseFloat(inputs[4].value) || 0;
      CNCApp.State.machine.dispensers[i].offsetY = parseFloat(inputs[5].value) || 0;
    });

    populateDispenserSelectors();
    CNCApp.Table.render();
    CNCApp.Canvas.render();
    CNCApp.Storage.saveAutoSave();
    modal.style.display = 'none';
  };

  document.getElementById('btnExportMachineProfile').onclick = () => {
    const prof = JSON.stringify(CNCApp.State.machine, null, 2);
    saveWithPicker(prof, 'machine_profile.json', 'application/json');
  };

  const profInp = document.getElementById('machineProfileInput');
  document.getElementById('btnImportMachineProfile').onclick = () => profInp.click();
  profInp.onchange = (e) => {
    const f = e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = (evt) => {
      try {
        CNCApp.State.machine = JSON.parse(evt.target.result);
        renderSettingsDispensers();
        populateDispenserSelectors();
        CNCApp.Table.render();
        CNCApp.Canvas.render();
      } catch(err) { alert('Невалиден профил!'); }
    };
    r.readAsText(f);
    profInp.value = '';
  };

  // --- НАСТАНИ ЗА АВТОМАТСКИ ГЕНЕРАТОР НА SVG ---
  const btnOpenSvgGenTop = document.getElementById('btnOpenSvgGenTop');
  if (btnOpenSvgGenTop) {
    btnOpenSvgGenTop.onclick = () => {
      if (CNCApp.SvgGenerator) CNCApp.SvgGenerator.openModal();
    };
  }

  const btnCloseSvgGen = document.getElementById('btnCloseSvgGen');
  if (btnCloseSvgGen) {
    btnCloseSvgGen.onclick = () => {
      if (CNCApp.SvgGenerator) CNCApp.SvgGenerator.closeModal();
    };
  }

  const btnCancelSvgGen = document.getElementById('btnCancelSvgGen');
  if (btnCancelSvgGen) {
    btnCancelSvgGen.onclick = () => {
      if (CNCApp.SvgGenerator) CNCApp.SvgGenerator.closeModal();
    };
  }

  const btnSvgGenLoadFile = document.getElementById('btnSvgGenLoadFile');
  const svgGenFileInput = document.getElementById('svgGenFileInput');
  if (btnSvgGenLoadFile && svgGenFileInput) {
    btnSvgGenLoadFile.onclick = () => svgGenFileInput.click();
    svgGenFileInput.onchange = (e) => {
      const f = e.target.files[0];
      if (!f) return;
      const r = new FileReader();
      r.onload = (evt) => {
        if (CNCApp.SvgGenerator) {
          CNCApp.SvgGenerator.parseAndAnalyze(evt.target.result);
          CNCApp.SvgGenerator.updateModalUI();
        }
      };
      r.readAsText(f);
      svgGenFileInput.value = '';
    };
  }

  const btnSvgGenUseCurrent = document.getElementById('btnSvgGenUseCurrent');
  if (btnSvgGenUseCurrent) {
    btnSvgGenUseCurrent.onclick = () => {
      if (!CNCApp.State.svgData) {
        alert("⚠️ Во моментов нема вчитано SVG на платното. Вчитајте SVG или изберете еден од готовите тест примероци.");
        return;
      }
      if (CNCApp.SvgGenerator) {
        CNCApp.SvgGenerator.parseAndAnalyze(CNCApp.State.svgData);
        CNCApp.SvgGenerator.updateModalUI();
      }
    };
  }

  const btnSvgSampleChannels = document.getElementById('btnSvgSampleChannels');
  if (btnSvgSampleChannels) {
    btnSvgSampleChannels.onclick = () => {
      if (CNCApp.SvgGenerator) {
        CNCApp.SvgGenerator.parseAndAnalyze(CNCApp.SvgGenerator.sampleSvgs.channelsAndPockets);
        CNCApp.SvgGenerator.updateModalUI();
      }
    };
  }

  const btnSvgSampleStar = document.getElementById('btnSvgSampleStar');
  if (btnSvgSampleStar) {
    btnSvgSampleStar.onclick = () => {
      if (CNCApp.SvgGenerator) {
        CNCApp.SvgGenerator.parseAndAnalyze(CNCApp.SvgGenerator.sampleSvgs.star);
        CNCApp.SvgGenerator.updateModalUI();
      }
    };
  }

  const btnSvgSampleFlower = document.getElementById('btnSvgSampleFlower');
  if (btnSvgSampleFlower) {
    btnSvgSampleFlower.onclick = () => {
      if (CNCApp.SvgGenerator) {
        CNCApp.SvgGenerator.parseAndAnalyze(CNCApp.SvgGenerator.sampleSvgs.flower3Color);
        CNCApp.SvgGenerator.updateModalUI();
      }
    };
  }

  const btnSvgSampleLines = document.getElementById('btnSvgSampleLines');
  if (btnSvgSampleLines) {
    btnSvgSampleLines.onclick = () => {
      if (CNCApp.SvgGenerator) {
        CNCApp.SvgGenerator.parseAndAnalyze(CNCApp.SvgGenerator.sampleSvgs.cncGridLines);
        CNCApp.SvgGenerator.updateModalUI();
      }
    };
  }

  const btnSvgGenPasteCode = document.getElementById('btnSvgGenPasteCode');
  if (btnSvgGenPasteCode) {
    btnSvgGenPasteCode.onclick = () => {
      const pasted = prompt("Пастирајте го вашиот SVG XML код овде (<svg ...> ... </svg>):");
      if (pasted && pasted.includes('<svg')) {
        if (CNCApp.SvgGenerator) {
          CNCApp.SvgGenerator.parseAndAnalyze(pasted);
          CNCApp.SvgGenerator.updateModalUI();
        }
      } else if (pasted) {
        alert("Невалиден SVG код!");
      }
    };
  }

  const btnSvgGenReplace = document.getElementById('btnSvgGenReplace');
  if (btnSvgGenReplace) {
    btnSvgGenReplace.onclick = () => {
      if (CNCApp.SvgGenerator) CNCApp.SvgGenerator.applyToProject(true);
    };
  }

  const btnSvgGenAppend = document.getElementById('btnSvgGenAppend');
  if (btnSvgGenAppend) {
    btnSvgGenAppend.onclick = () => {
      if (CNCApp.SvgGenerator) CNCApp.SvgGenerator.applyToProject(false);
    };
  }
});