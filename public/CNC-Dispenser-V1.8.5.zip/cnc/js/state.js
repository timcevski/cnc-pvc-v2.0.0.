window.CNCApp = window.CNCApp || {};

CNCApp.State = {
  points: [],
  selectedIndices: new Set(),
  activePointIndex: null,
  lastSelectedRowIndex: null,
  header: '',
  footer: 'G28.1 X2 Y2\r\nG1 X1 Y1 F2000\r\nM5\r\nM30',
  svgData: null,
  svgImage: null,
  history: [],
  historyIndex: -1,
  isAddMode: false,
  stepIncrement: 0.05,
  shadedDispensers: new Set(),
  showClearanceRings: true,
  showSvg: true,

  machine: {
    name: "Стандардна Машина (5 Диспензери)",
    systemDelayLower: 150,
    systemDelayRaise: 150,
    mCommandLatency: 120,
    valveOpenCmd: "M103",
    valveCloseCmd: "M203",
    timeUnit: "ms",
    decimalSeparator: ".",
    dispensers: [
      { id: 1, name: "Боја 1", color: "#2563eb", lowerCmd: "M104", raiseCmd: "M204", offsetX: -0.30, offsetY: 34.45 },
      { id: 2, name: "Боја 2", color: "#059669", lowerCmd: "M105", raiseCmd: "M205", offsetX: 39.70, offsetY: 34.45 },
      { id: 3, name: "Боја 3", color: "#dc2626", lowerCmd: "M106", raiseCmd: "M206", offsetX: 79.70, offsetY: 34.45 },
      { id: 4, name: "Боја 4", color: "#d97706", lowerCmd: "M107", raiseCmd: "M207", offsetX: 119.70, offsetY: 34.45 },
      { id: 5, name: "Боја 5", color: "#7c3aed", lowerCmd: "M108", raiseCmd: "M208", offsetX: 159.70, offsetY: 34.45 }
    ]
  },

  createPoint: function(x, y) {
    return {
      active: true,
      x: parseFloat(parseFloat(x || 0).toFixed(3)),
      y: parseFloat(parseFloat(y || 0).toFixed(3)),
      speed: 1000,
      lower: true,
      valveStart: true,
      time: '',
      valveStop: true,
      raise: true,
      dispenser: 1,
      group1: '',
      group2: ''
    };
  },

  snapshot: function() {
    if (this.historyIndex < this.history.length - 1) {
      this.history = this.history.slice(0, this.historyIndex + 1);
    }
    this.history.push(JSON.stringify(this.points));
    if (this.history.length > 50) this.history.shift();
    this.historyIndex = this.history.length - 1;
    if (CNCApp.Storage) CNCApp.Storage.saveAutoSave();
  },

  undo: function() {
    if (this.historyIndex > 0) {
      this.historyIndex--;
      this.points = JSON.parse(this.history[this.historyIndex]);
      CNCApp.Table.render();
      CNCApp.Canvas.render();
    }
  },

  redo: function() {
    if (this.historyIndex < this.history.length - 1) {
      this.historyIndex++;
      this.points = JSON.parse(this.history[this.historyIndex]);
      CNCApp.Table.render();
      CNCApp.Canvas.render();
    }
  }
};